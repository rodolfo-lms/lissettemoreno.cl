<?php
/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 * 
 * 
 * @link https://themeforest.net/user/pixelcurve
 *
 * @package oxiz-core\includes
 * @author Pixelcurve <help.pixelcurve@gmail.com>
 * @since 1.0.0
 */
class Corpix_Core_Deactivator
{
	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate()
	{
	}
}

<?php $settings = $this->get_settings_for_display();?>

<div class="corpix-hero-section-04 align-i-center <?php echo esc_attr($hide_animated_shape)?>">

    <?php if($settings['bg_text']) : ?>
	    <div class="corpix-bg-text">
        <?php echo $settings['bg_text']; ?>
        </div>
    <?php endif;?>

	<div class="corpix-container">
		<div class="row align-i-center">
			<div class="col-xl-7 col-lg-7">
				<!-- Hero Content Start -->
				<div class="hero-content">
                    <?php if($settings['sub_title']) : ?>
                        <h3 class="sub-title" data-aos-delay="600" data-aos="fade-up">
                            <?php echo $settings['sub_title']; ?>
                        </h3>
                    <?php endif;?> 
					<?php if($settings['title']) : ?>
                        <h2 class="title" data-aos="fade-up" data-aos-delay="700">
                            <?php echo $settings['title']; ?>
                        </h2>
                    <?php endif;?> 

					<?php if($settings['show_btn']) : ?>
                        <div class="corpix-hero-btn" data-aos="fade-up" data-aos-delay="900">
                            <?php if($settings['btn_link']['url']):?>
                                <a class="corpix-btn" <?php if($settings['btn_link']['nofollow'] == 'on'): echo 'rel ="nofollow"'; endif;?> <?php if($settings['btn_link']['is_external'] == 'on'): echo 'target="_blank"'; endif; ?> href="<?php echo $settings['btn_link']['url'] ?>">
                            <?php endif ?>
                                <?php echo $settings['btn_text']; ?> 

                                    <span class="btn-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg"  height="24px" viewBox="0 0 32 24" width="24px">
                                            <path d="m18.7188 6.78125-1.4376 1.4375 6.7813 6.78125h-20.0625v2h20.0625l-6.7813 6.7812 1.4376 1.4376 8.5-8.5.6874-.7188-.6874-.7188z" />
                                        </svg>
                                    </span>

                            <?php if($settings['btn_link']['url']): ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
				</div>
				<!-- Hero Content End -->
			</div>
			<div class="col-xl-5 col-lg-5">
				<div class="hero-img">
					<div class="shape-01"></div>
					<img src="<?php echo esc_url($settings['hero_image']['url'])?>" alt="">
				</div>
			</div>
		</div>
	</div>
</div>


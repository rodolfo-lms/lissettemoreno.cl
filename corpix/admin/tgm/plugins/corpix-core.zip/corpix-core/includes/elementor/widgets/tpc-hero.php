<?php
/*
 * This template can be overridden by copying it to yourtheme/corpix-core/elementor/widgets/tpc-Cat-item.php.
*/
namespace TPCAddons\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.

use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;



use Elementor\{Widget_Base, Controls_Manager, Control_Media, Group_Control_Image_Size, Group_Control_Background, Group_Control_Box_Shadow, Group_Control_Typography, Utils, Embed};

use TPCAddons\Corpix_Global_Variables as Corpix_Globals;

class TPC_Hero extends Widget_Base
{

    public function get_name()
    {
        return 'tpc-hero';
    }

    public function get_title()
    {
        return esc_html__('Hero Section', 'corpix-core');
    }

    public function get_icon()
    {
        return 'tpc-icon eicon-slider-push';
    }

    public function get_categories()
    {
        return ['tpc-extensions'];
    }

protected function register_controls()
{

    $this->start_controls_section(
        'general_section',
        [
            'label' => __( 'General', 'corpix-core' ),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]
    );

    $this->add_control(
        'layout_style',
        [
            'label' => __( 'Style', 'corpix-core' ),
            'type' => Controls_Manager::SELECT,
            'default' => '1',
            'options' => [
                '1' => esc_html__('1 / One', 'corpix-core'),
                '2' => esc_html__('2 / Two', 'corpix-core'),
                '3' => esc_html__('3 / Three', 'corpix-core'),
                '4' => esc_html__('4 / Four', 'corpix-core'),
                '5' => esc_html__('5 / Five', 'corpix-core'),
                '6' => esc_html__('6 / Six', 'corpix-core'),
            ],
        ]
    );

    $this->add_responsive_control(
        'hero_content_align',
        [
            'label' => esc_html__( 'Alignment', 'corpix-core' ),
            'type' => Controls_Manager::CHOOSE,
            'options' => [
                'left' => [
                    'title' => esc_html__( 'Left', 'corpix-core' ),
                    'icon' => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => esc_html__( 'Center', 'corpix-core' ),
                    'icon' => 'eicon-text-align-center',
                ],
                'right' => [
                    'title' => esc_html__( 'Right', 'corpix-core' ),
                    'icon' => 'eicon-text-align-right',
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section .hero-content' => 'text-align: {{VALUE}};',
                '{{WRAPPER}} .corpix-hero-section-02 .hero-content' => 'text-align: {{VALUE}};',
                '{{WRAPPER}} .corpix-hero-section-03 .hero-content' => 'text-align: {{VALUE}};',
                '{{WRAPPER}} .corpix-hero-section-04 .hero-content' => 'text-align: {{VALUE}};',
                '{{WRAPPER}} .corpix-hero-section-05 .hero-content' => 'text-align: {{VALUE}};',
                '{{WRAPPER}} .corpix-hero-section-06 .hero-content' => 'text-align: {{VALUE}};',
            ],
        ]
    );
    $this->add_control(
        'section_bg_color',
        [
            'label' => esc_html__( 'Background Color', 'corpix-core' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section-03' => 'background: {{VALUE}}',
            ],
            'condition' => [
                'layout_style' => '3',
            ],
        ]
    );
    $this->add_control(
        'bg_image',
        [
            'label' => esc_html__( 'Background Image', 'corpix-core' ),
            'type' => Controls_Manager::HEADING,
             'separator' => 'before',
        ]
    );

    $this->add_group_control(
        Group_Control_Background::get_type(),
        [
            'name' => 'section_background',
            'label' => __( 'Background Overlay', 'corpix-core' ),
            'types' => [ 'classic', 'gradient' ],
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section',
                '{{WRAPPER}} .corpix-hero-section-02',
                '{{WRAPPER}} .corpix-hero-section-03',
                '{{WRAPPER}} .corpix-hero-section-04',
                '{{WRAPPER}} .corpix-hero-section-05',
                '{{WRAPPER}} .corpix-hero-section-06',
            ],
            'condition' => [
                'layout_style!' => '3',
            ],
        ]
    );

    $this->add_control(
        'image_bg_overlay_title',
        [
            'label' => esc_html__( 'Image Overlay', 'corpix-core' ),
            'type' => Controls_Manager::HEADING,
             'separator' => 'before',
             'condition' => [
                'layout_style!' => '3',
            ],
        ]
        
    );

    $this->add_control(
        'bg_overlay_color',
        [
            'label' => esc_html__( 'Background Overlay Color', 'corpix-core' ),
            'type' => Controls_Manager::COLOR,
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section::before' => 'background-color: {{VALUE}}',
                '{{WRAPPER}} .corpix-hero-section-02::before' => 'background-color: {{VALUE}}',
                '{{WRAPPER}} .corpix-hero-section-04::before' => 'background-color: {{VALUE}}',
                '{{WRAPPER}} .corpix-hero-section-05::before' => 'background-color: {{VALUE}}',
                '{{WRAPPER}} .corpix-hero-section-06::before' => 'background-color: {{VALUE}}',
            ],
            'condition' => [
                'layout_style!' => '3',
            ],
        ]
    );
    $this->add_responsive_control(
        'hero_wrapper_bg',
        [
            'label' => __( 'Wrapper Bg Image', 'corpix-core' ),
            'type' => Controls_Manager::MEDIA,
            'condition' => [
                'layout_style' => '5',
            ],
        ]
    );

    $this->end_controls_section();

    $this->start_controls_section(
        'content_section',
        [
            'label' => __( 'Content', 'corpix-core' ),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]
    );

    // Title Start

    $this->add_control(
        'title',
        [
            'label' => __( 'Title', 'corpix-core' ),
            'type' => Controls_Manager::TEXTAREA,
            'default' => __( 'We brand your project', 'corpix-core' ),
            'label_block' => true,
            'condition' => [
                'layout_style!' => '3',
            ]
        ]
    );

    $this->add_control(
        'title_animation',
        [
            'label' => esc_html__( 'Title Animation', 'corpix-core' ),
            'type' => Controls_Manager::SELECT2,
            'options' => [
                'none' => esc_html__( 'None', 'corpix-core' ),
                'fade' => esc_html__( 'Fade', 'corpix-core' ),
                'fade-up' => esc_html__( 'Fade Up', 'corpix-core' ),
                'fade-down' => esc_html__( 'Fade Down', 'corpix-core' ),
                'fade-left' => esc_html__( 'Fade Left', 'corpix-core' ),
                'fade-right' => esc_html__( 'Fade Right', 'corpix-core' ),
                'fade-up-right' => esc_html__( 'Fade Up Right', 'corpix-core' ),
                'fade-up-left' => esc_html__( 'Fade Up Left', 'corpix-core' ),
                'fade-down-right' => esc_html__( 'Fade Down Right', 'corpix-core' ),
                'fade-down-left' => esc_html__( 'Fade Down Left', 'corpix-core' ),
                'flip-up' => esc_html__( 'Flip Up', 'corpix-core' ),
                'flip-down' => esc_html__( 'Flip Down', 'corpix-core' ),
                'flip-left' => esc_html__( 'Flip Left', 'corpix-core' ),
                'flip-right' => esc_html__( 'Flip Right', 'corpix-core' ),
                'slide-up' => esc_html__( 'Slide Up', 'corpix-core' ),
                'slide-down' => esc_html__( 'Slide Down', 'corpix-core' ),
                'slide-left' => esc_html__( 'Slide Left', 'corpix-core' ),
                'slide-right' => esc_html__( 'Slide Right', 'corpix-core' ),
                'zoom-in' => esc_html__( 'Zoom In', 'corpix-core' ),
                'zoom-in-up' => esc_html__( 'Zoom In Up', 'corpix-core' ),
                'zoom-in-down' => esc_html__( 'Zoom In Down', 'corpix-core' ),
                'zoom-in-left' => esc_html__( 'Zoom In Left', 'corpix-core' ),
                'zoom-in-right' => esc_html__( 'Zoom In Right', 'corpix-core' ),
                'zoom-out' => esc_html__( 'Zoom Out', 'corpix-core' ),
                'zoom-out-up' => esc_html__( 'Zoom Out Up', 'corpix-core' ),
                'zoom-out-down' => esc_html__( 'Zoom Out Down', 'corpix-core' ),
                'zoom-out-left' => esc_html__( 'Zoom Out Left', 'corpix-core' ),
                'zoom-out-right' => esc_html__( 'Zoom Out Right', 'corpix-core' )
            ],
            'default' => 'none',
            'frontend_available' => true,
        ]
    );

    $this->add_control(
        'title_1',
        [
            'label' => esc_html__('Title 1st Part', 'corpix-core'),
            'type' => Controls_Manager::TEXTAREA,
            'dynamic' => ['active' => true],
            // 'rows' => 1,
            'placeholder' => esc_attr__('1st part', 'corpix-core'),
            'default' => 'We<span>Create</span>High', 'corpix-core',
            'condition' => [
                'layout_style' => '3',
            ],
        ]
    );

    $this->add_control(
        'title_2',
        [
            'label' => esc_html__('Title 2nd Part', 'corpix-core'),
            'type' => Controls_Manager::TEXTAREA,
            'dynamic' => ['active' => true],
            // 'rows' => 1,
            'placeholder' => esc_attr__('2nd part', 'corpix-core'),
            'default' => 'Impact<span>Digital</span>', 'corpix-core',
            'condition' => [
                'layout_style' => '3',
            ],
        ]
    );

    $this->add_control(
        'title_3',
        [
            'label' => esc_html__('Title 3rd Part', 'corpix-core'),
            'type' => Controls_Manager::TEXTAREA,
            'dynamic' => ['active' => true],
            // 'rows' => 1,
            'placeholder' => esc_attr__('3rd part', 'corpix-core'),
            'default' => 'Experience', 'corpix-core',
            'condition' => [
                'layout_style' => '3',
            ],
        ]
    );
  
    $this->add_control(
        'sub_title',
        [
            'label' => __( 'Sub Title', 'corpix-core' ),
            'type' => Controls_Manager::TEXTAREA,
            'default' => __( 'Outstanding Creative Agency', 'corpix-core' ),
            'label_block' => true,
            'rows' => 1,
        ]
    );
    $this->add_control(
        'bg_text',
        [
            'label' => __( 'Background Text', 'corpix-core' ),
            'type' => Controls_Manager::TEXTAREA,
            'default' => __( 'Agency', 'corpix-core' ),
            'label_block' => true,
            'rows' => 1,
            'condition' => [
                'layout_style' => '4',
            ],
        ]
    );


    $this->end_controls_section();
    

    $this->start_controls_section(
        'section_image',
        [
            'label' => esc_html__('Hero Image', 'corpix-core'),
           'condition' => [
                'layout_style' => ['4','3'],
            ],
        ]
    );

    $this->add_control(
        'hero_image',
        [
            'label' => __( 'Hero Image', 'corpix-core' ),
            'type' => Controls_Manager::MEDIA,
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
        ]
    );
    $this->add_control(
        'image_shape_1',
        [
            'label' => __( 'Circle Shape', 'corpix-core' ),
            'type' => Controls_Manager::MEDIA,
            'default' => [
                'url' => '',
            ],
            'condition' => [
                'layout_style' => ['3'],
            ],
        ]
    );
    $this->add_control(
        'image_shape_2',
        [
            'label' => __( 'Dot Shape', 'corpix-core' ),
            'type' => Controls_Manager::MEDIA,
            'default' => [
                'url' => '',
            ],
            'condition' => [
                'layout_style' => ['3'],
            ],
        ]
    );

    $this->end_controls_section();
   
    // Start button
    $this->start_controls_section(
        'section_btn',
        [
            'label' => __( 'Button', 'corpix-core' ),
            'tab'   => Controls_Manager::TAB_CONTENT,
            'condition' => [
                'layout_style!' => '3',
            ],
        ]
    );

    $this->add_control(
        'show_btn',
        [
            'label' => esc_html__('Button', 'corpix-core'),
            'type' => Controls_Manager::SWITCHER,
            'default' => 'yes'
        ]
    );

    $this->add_control(
        'btn_text',
        [
            'label'       => __('Button Text', 'corpix-core'),
            'type'        => Controls_Manager::TEXT,
            'default'     => 'Our Services',
            'label_block' => true,
        ]
    );

    $this->add_control(
        'btn_link',
        [
            'label' => __( 'Link', 'corpix-core' ),
            'type' => Controls_Manager::URL,
            'placeholder' => __( 'https://your-link.com', 'corpix-core' ),
            'show_external' => true,
            'default' => [
                'url' => '#',
            ],
        ]
    );

    $this->end_controls_section();


    // Style Section Start

    $this->start_controls_section(
        'section_general_style',
        [
            'label' => esc_html__('General', 'corpix-core'),
            'tab' => Controls_Manager::TAB_STYLE,
        ]
        
    );
    $this->add_responsive_control(
        'section_height',
        [
            'label'     => __('Section Height', 'corpix-core'),
            'type'      => Controls_Manager::SLIDER,
            'range'     => [
                'px' => [
                    'min' => 100,
                    'max' => 1600,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section' => 'height: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .corpix-hero-section-02' => 'height: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .corpix-hero-section-03' => 'height: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .corpix-hero-section-04' => 'height: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .corpix-hero-section-05' => 'height: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .corpix-hero-section-06' => 'height: {{SIZE}}{{UNIT}};',
            ],
            

        ]
    );  
    $this->add_responsive_control(
        'content_position',
        [
            'label'     => __('Content Position', 'corpix-core'),
            'type'      => Controls_Manager::SLIDER,
            'range'     => [
                'px' => [
                    'min' => -1000,
                    'max' => 1000,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section .hero-content' => 'padding-top: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'layout_style' => '1',
                'layout_style!' => '2',
            ],
        ]
    ); 
    
    $this->add_responsive_control(
        'content_max_width',
        [
            'label'     => __('Content Max Width', 'corpix-core'),
            'type'      => Controls_Manager::SLIDER,
            'range'     => [
                'px' => [
                    'min' => 0,
                    'max' => 1000,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section-02 .hero-content' => 'max-width: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .corpix-hero-section-06 .hero-content' => 'max-width: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'layout_style' => ['2', '6'],
            ],
        ]
    );
    $this->end_controls_section();
  
    $this->start_controls_section(
        'shape_section_background',
        [
            'label' => esc_html__('Shape', 'corpix-core'),
            'tab' => Controls_Manager::TAB_STYLE,
            'condition' => [
                'layout_style!' => '6',
            ],
        ]
    );

    $this->add_control(
        'hide_animated_shape',
        [
            'label' => esc_html__( 'Hide Animated Shape?', 'corpix-core' ),
            'type' => Controls_Manager::SWITCHER,
            'label_on' => esc_html__( 'Yes', 'corpix-core' ),
            'label_off' => esc_html__( 'No', 'corpix-core' ),
            'return_value' => 'yes',
            'default' => 'no',
            'condition' => [
                'layout_style' => ['1', '3', '4'],
            ],
        ]
    );


    $this->add_control(
        'shape_color_option',
        [
            'label' => esc_html__( 'Shape Color', 'corpix-core' ),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before',
        ]
    );
    $this->add_control(
        'shape_color_1',
        [
            'label' => esc_html__( 'Shape Color Group 01', 'corpix-core' ),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                // Homepage 1 Selectors
                '{{WRAPPER}} .corpix-hero-section .shape-2' => 'border-color: {{VALUE}};',
                '{{WRAPPER}} .corpix-hero-section .shape-3' => 'border-color: {{VALUE}};',
                '{{WRAPPER}} .corpix-hero-section .shape-4' => 'background-color: {{VALUE}};',
                // Homepage 2 Selectors
                '{{WRAPPER}} .corpix-hero-section-02 .hero-content .shape-1 svg' => 'fill: {{VALUE}};',
                '{{WRAPPER}} .corpix-hero-section-02 .hero-content .shape-2 svg' => 'fill: {{VALUE}};',
                // Homepage 3 Selector
                '{{WRAPPER}} .corpix-hero-section-03 .shape-3' => 'border-color: {{VALUE}};',
                // Hompage 4 Selectors
                '{{WRAPPER}} .corpix-hero-section-04 .hero-img .shape-01' => 'border-color: {{VALUE}};',
                // Hompage 5 Selectors
                '{{WRAPPER}} .corpix-hero-section-05 .shape-1 svg' => 'fill: {{VALUE}};',
                '{{WRAPPER}} .corpix-hero-section-05 .shape-2 svg' => 'stroke: {{VALUE}};',
                
            ],
            
        ]
    );

    $this->add_control(
        'shape_color_2',
        [
            'label' => esc_html__( 'Shape Color Group 02', 'corpix-core' ),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                // Homepage 1 Selectors
                '{{WRAPPER}} .corpix-hero-section .shape-5' => 'border-color: {{VALUE}};',
                // Homepage 2 Selectors
                '{{WRAPPER}} .corpix-hero-section-02 .hero-content .shape-3 svg' => 'fill: {{VALUE}};',
                // Homepage 4 Selectors
                '{{WRAPPER}} .corpix-hero-section-04 .hero-img::before' => 'background-color: {{VALUE}};',
                // Hompage 5 Selectors
                '{{WRAPPER}} .corpix-hero-section-05 .shape-3 svg' => 'fill: {{VALUE}};',
                '{{WRAPPER}} .corpix-hero-section-05 .shape-4 svg' => 'stroke: {{VALUE}};',
            ],

            'condition' => [
                'layout_style!' => '3',
            ],
        ]
    );

    //Shape A
    $this->add_control(
        'shape_a_option',
        [
            'label' => esc_html__( 'Shape A', 'corpix-core' ),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before',
            'condition' => [
                'layout_style' => '1',
            ],
        ]
    );

    $this->add_responsive_control(
        'shape_a_size',
        [
            'label'     => __('Shape A Size', 'corpix-core'),
            'type'      => Controls_Manager::SLIDER,
            'range'     => [
                'px' => [
                    'min' => 0,
                    'max' => 600,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section .shape-1' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'layout_style' => '1',
            ],
        ]
    );

    $this->add_responsive_control(
        'shape_a_pos_x',
        [
            'label'     => __('Shape Position X', 'corpix-core'),
            'type'      => Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%'],
            'range'     => [
                '%' => [
                    'min' => -100,
                    'max' => 100,
                ],
                'px' => [
                    'min' => -500,
                    'max' => 600,
                ],
            ],
            'default' => [
                'unit' => 'px',
            ],
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section .shape-1' => 'left: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'layout_style' => '1',
            ],
        ]
    );

    $this->add_responsive_control(
        'shape_a_pos_y',
        [
            'label'     => __('Shape Position Y', 'corpix-core'),
            'type'      => Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%'],
            'range'     => [
                '%' => [
                    'min' => -100,
                    'max' => 100,
                ],
                'px' => [
                    'min' => -500,
                    'max' => 600,
                ],
            ],
            'default' => [
                'unit' => 'px',
            ],
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section .shape-1' => 'top: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'layout_style' => '1',
            ],
        ]
    );

    //Shape B
    $this->add_control(
        'shape_b_option',
        [
            'label' => esc_html__( 'Shape B', 'corpix-core' ),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before',
            'condition' => [
                'layout_style' => '1',
            ],
        ]
    );

    $this->add_responsive_control(
        'shape_b_size',
        [
            'label'     => __('Shape B Size', 'corpix-core'),
            'type'      => Controls_Manager::SLIDER,
            'range'     => [
                'px' => [
                    'min' => 0,
                    'max' => 1000,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section .shape-2' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'layout_style' => '1',
            ],
        ]
    );

    $this->add_responsive_control(
        'shape_b_pos_x',
        [
            'label'     => __('Shape Position X', 'corpix-core'),
            'type'      => Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%'],
            'range'     => [
                '%' => [
                    'min' => -100,
                    'max' => 100,
                ],
                'px' => [
                    'min' => -500,
                    'max' => 600,
                ],
            ],
            'default' => [
                'unit' => 'px',
            ],
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section .shape-2' => 'right: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'layout_style' => '1',
            ],
        ]
    );

    $this->add_responsive_control(
        'shape_b_pos_y',
        [
            'label'     => __('Shape Position Y', 'corpix-core'),
            'type'      => Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%'],
            'range'     => [
                '%' => [
                    'min' => -100,
                    'max' => 100,
                ],
                'px' => [
                    'min' => -500,
                    'max' => 600,
                ],
            ],
            'default' => [
                'unit' => 'px',
            ],
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section .shape-2' => 'top: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'layout_style' => '1',
            ],
        ]
    );

    //Shape C
    $this->add_control(
        'shape_c_option',
        [
            'label' => esc_html__( 'Shape C', 'corpix-core' ),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before',
            'condition' => [
                'layout_style' => '1',
            ],
        ]
    );

    $this->add_responsive_control(
        'shape_c_size',
        [
            'label'     => __('Shape C Size', 'corpix-core'),
            'type'      => Controls_Manager::SLIDER,
            'range'     => [
                'px' => [
                    'min' => 0,
                    'max' => 1000,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section .shape-3' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'layout_style' => '1',
            ],
        ]
    );

    $this->add_responsive_control(
        'shape_c_pos_x',
        [
            'label'     => __('Shape Position X', 'corpix-core'),
            'type'      => Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%'],
            'range'     => [
                '%' => [
                    'min' => -100,
                    'max' => 100,
                ],
                'px' => [
                    'min' => -500,
                    'max' => 600,
                ],
            ],
            'default' => [
                'unit' => 'px',
            ],
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section .shape-3' => 'right: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'layout_style' => '1',
            ],
        ]
    );

    $this->add_responsive_control(
        'shape_c_pos_y',
        [
            'label'     => __('Shape Position Y', 'corpix-core'),
            'type'      => Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%'],
            'range'     => [
                '%' => [
                    'min' => -100,
                    'max' => 100,
                ],
                'px' => [
                    'min' => -500,
                    'max' => 600,
                ],
            ],
            'default' => [
                'unit' => 'px',
            ],
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section .shape-3' => 'top: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'layout_style' => '1',
            ],
        ]
    );
    

    //Shape D
    $this->add_control(
        'shape_d_option',
        [
            'label' => esc_html__( 'Shape D', 'corpix-core' ),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before',
            'condition' => [
                'layout_style' => '1',
            ],
        ]
    );

    $this->add_responsive_control(
        'shape_d_size',
        [
            'label'     => __('Shape D Size', 'corpix-core'),
            'type'      => Controls_Manager::SLIDER,
            'range'     => [
                'px' => [
                    'min' => 0,
                    'max' => 1000,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section .shape-4' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'layout_style' => '1',
            ],
        ]
    );

    $this->add_responsive_control(
        'shape_d_pos_x',
        [
            'label'     => __('Shape Position X', 'corpix-core'),
            'type'      => Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%'],
            'range'     => [
                '%' => [
                    'min' => -100,
                    'max' => 100,
                ],
                'px' => [
                    'min' => -500,
                    'max' => 600,
                ],
            ],
            'default' => [
                'unit' => 'px',
            ],
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section .shape-4' => 'right: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'layout_style' => '1',
            ],
        ]
    );

    $this->add_responsive_control(
        'shape_d_pos_y',
        [
            'label'     => __('Shape Position Y', 'corpix-core'),
            'type'      => Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%'],
            'range'     => [
                '%' => [
                    'min' => -100,
                    'max' => 100,
                ],
                'px' => [
                    'min' => -500,
                    'max' => 600,
                ],
            ],
            'default' => [
                'unit' => 'px',
            ],
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section .shape-4' => 'bottom: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'layout_style' => '1',
            ],
        ]
    );

     //Shape E
     $this->add_control(
        'shape_e_option',
        [
            'label' => esc_html__( 'Shape E', 'corpix-core' ),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before',
            'condition' => [
                'layout_style' => '1',
            ],
        ]
    );

    $this->add_responsive_control(
        'shape_e_size',
        [
            'label'     => __('Shape E Size', 'corpix-core'),
            'type'      => Controls_Manager::SLIDER,
            'range'     => [
                'px' => [
                    'min' => 0,
                    'max' => 1000,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section .shape-5' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'layout_style' => '1',
            ],
        ]
    );

    $this->add_responsive_control(
        'shape_e_pos_x',
        [
            'label'     => __('Shape Position X', 'corpix-core'),
            'type'      => Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%'],
            'range'     => [
                '%' => [
                    'min' => -100,
                    'max' => 100,
                ],
                'px' => [
                    'min' => -500,
                    'max' => 600,
                ],
            ],
            'default' => [
                'unit' => 'px',
            ],
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section .shape-5' => 'right: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'layout_style' => '1',
            ],
        ]
    );

    $this->add_responsive_control(
        'shape_e_pos_y',
        [
            'label'     => __('Shape Position Y', 'corpix-core'),
            'type'      => Controls_Manager::SLIDER,
            'size_units' => [ 'px', '%'],
            'range'     => [
                '%' => [
                    'min' => -100,
                    'max' => 100,
                ],
                'px' => [
                    'min' => -500,
                    'max' => 600,
                ],
            ],
            'default' => [
                'unit' => 'px',
            ],
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section .shape-5' => 'bottom: {{SIZE}}{{UNIT}};',
            ],
            'condition' => [
                'layout_style' => '1',
            ],
        ]
    );

    $this->end_controls_section();

    $this->start_controls_section(
        'style_section',
        [
            'label' => __( 'Content', 'corpix-core' ),
            'tab'   => Controls_Manager::TAB_STYLE,
        ]
    );

    $this->add_control(
        'heading_title',
        [
            'label' => esc_html__( 'Title', 'corpix-core' ),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before',
        ]
    );

    $this->add_control(
        'title_color',
        [
            'label' => esc_html__( 'Color', 'corpix-core' ),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section .hero-content .title' => 'color: {{VALUE}};',
                '{{WRAPPER}} .corpix-hero-section-02 .hero-content .title' => 'color: {{VALUE}};',
                '{{WRAPPER}} .corpix-hero-section-04 .hero-content .title' => 'color: {{VALUE}};',
            ],
            'condition' => [
                'layout_style!' => '3'
            ],      
        ]
    );
    $this->add_control(
        'title_color_1',
        [
            'label' => esc_html__( 'Title Color 01', 'corpix-core' ),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section-03 .hero-content .title .title-1' => 'color: {{VALUE}};',
            ],
            'condition' => [
                'layout_style' => '3'
            ],      
        ]
    );
    
    $this->add_control(
        'title_color_2',
        [
            'label' => esc_html__( 'Title Color 02', 'corpix-core' ),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section-03 .hero-content .title .title-1>span' => 'color: {{VALUE}};',
            ],
            'condition' => [
                'layout_style' => '3'
            ],      
        ]
    );
    $this->add_control(
        'title_color_3',
        [
            'label' => esc_html__( 'Title Color 03', 'corpix-core' ),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section-03 .hero-content .title .title-2' => 'color: {{VALUE}};',
            ],
            'condition' => [
                'layout_style' => '3'
            ],      
        ]
    );
    $this->add_control(
        'title_bg_color_1',
        [
            'label' => esc_html__( 'Title Bg Color 01', 'corpix-core' ),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section-03 .hero-content .title .title-1' => 'background-color: {{VALUE}};',
            ],
            'condition' => [
                'layout_style' => '3'
            ],      
        ]
    );
    $this->add_control(
        'title_bg_color_2',
        [
            'label' => esc_html__( 'Title Bg Color 02', 'corpix-core' ),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section-03 .hero-content .title .title-2' => 'background-color: {{VALUE}};',
            ],
            'condition' => [
                'layout_style' => '3'
            ],      
        ]
    );
    $this->add_control(
        'title_underline_color',
        [
            'label' => esc_html__( 'Title Underline Color', 'corpix-core' ),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section .hero-content .title' => 'text-decoration-color: {{VALUE}};',
            ],
            'condition' => ['layout_style' => '1'],
            
        ]
    );

    $this->add_responsive_control(
        'title_bottom_space',
        [
            'label' => esc_html__( 'Spacing', 'corpix-core' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 100,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section .hero-content .title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .corpix-hero-section-02 .hero-content .title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .corpix-hero-section-04 .hero-content .title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .corpix-hero-section-03 .hero-content .title span' => 'margin-top: {{SIZE}}{{UNIT}};',
            ],
        ]
    );

    $this->add_group_control(
        Group_Control_Typography::get_type(),
        [
            'name' => 'title_typography',
            'selector' => '
                    {{WRAPPER}} .corpix-hero-section .hero-content .title,.corpix-hero-section-02 .hero-content .title, .corpix-hero-section-04 .hero-content .title, .corpix-hero-section-03 .hero-content .title span, .corpix-hero-section-03 .hero-content .title .title-1, .corpix-hero-section-03 .hero-content .title title-2, .corpix-hero-section-05 .hero-content .title,  .corpix-hero-section-06 .hero-content .title',
            'global' => [
                'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
            ],
            
        ]
    );

    $this->add_control(
        'sub_heading',
        [
            'label' => esc_html__( 'Sub Title', 'corpix-core' ),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before',
        ]
    );

    $this->add_control(
        'sub_heading_color',
        [
            'label' => esc_html__( 'Color', 'corpix-core' ),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section .hero-content .sub-title' => 'color: {{VALUE}};',
                '{{WRAPPER}} .corpix-hero-section-02 .hero-content .sub-title' => 'color: {{VALUE}};',
                '{{WRAPPER}} .corpix-hero-section-03 .hero-content .sub-title' => 'color: {{VALUE}};',
                '{{WRAPPER}} .corpix-hero-section-04 .hero-content .sub-title' => 'color: {{VALUE}};',
            ],
            
        ]
    );

    $this->add_responsive_control(
        'sub_heading_bottom_space',
        [
            'label' => esc_html__( 'Spacing', 'corpix-core' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 100,
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section .hero-content .sub-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .corpix-hero-section-02 .hero-content .sub-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .corpix-hero-section-03 .hero-content .sub-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .corpix-hero-section-04 .hero-content .sub-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
            ],
        ]
    );
    $this->add_group_control(
        Group_Control_Typography::get_type(),
        [
            'name' => 'sub_heading_typography',
            'selector' => '{{WRAPPER}} .corpix-hero-section .hero-content .sub-title,.corpix-hero-section-02 .hero-content .sub-title,.corpix-hero-section-03 .hero-content .sub-title,.corpix-hero-section-04 .hero-content .sub-title, .corpix-hero-section-05 .hero-content .sub-title, .corpix-hero-section-06 .hero-content .sub-title',
            'global' => [
                'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
            ],
        ]
    );


    $this->add_control(
        'bg_text_style',
        [
            'label' => esc_html__( 'Background Text', 'corpix-core' ),
            'type' => Controls_Manager::HEADING,
            'separator' => 'before',
            'condition' => ['layout_style' => '4'],
        ]
    );

    $this->add_control(
        'bg_text_color',
        [
            'label' => esc_html__( 'Color', 'corpix-core' ),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .corpix-hero-section-04 .corpix-bg-text' => '-webkit-text-stroke-color: {{VALUE}};',
            ],
            'condition' => ['layout_style' => '4'],
        ]
    );

    $this->add_group_control(
        Group_Control_Typography::get_type(),
        [
            'name' => 'bg_text_typography',
            'selector' => '{{WRAPPER}} .corpix-hero-section-04 .corpix-bg-text',
            'global' => [
                'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
            ],
            'condition' => ['layout_style' => '4'],
        ]
    );




    $this->end_controls_section();
        // STYLE -> Button

        $this->start_controls_section(
            'section_style_btn',
            [
                'label' => esc_html__('Button', 'corpix-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => ['layout_style!' => '3'],
            ]
            
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'selector' => '{{WRAPPER}} .hero-content .corpix-hero-btn .corpix-btn',
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
                ],
                'condition' => ['layout_style' => '4'],
            ]
        );
        $this->start_controls_tabs('text_color_tabs');
        $this->start_controls_tab(
            'tab_text_idle',
            ['label' => esc_html__('Idle', 'corpix-core')]
        );
        $this->add_control(
            'text_color_idle',
            [
                'label' => esc_html__('Color', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .corpix-hero-btn .corpix-btn' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .corpix-hero-btn-02 .corpix-btn' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'btn_bg_color',
            [
                'label' => esc_html__('Background Color', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .corpix-hero-btn .corpix-btn' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .corpix-hero-btn-02 .corpix-btn' => 'background-color: {{VALUE}};',
                    
                ],
            ]
        );
        $this->add_control(
            'btn_icon_color',
            [
                'label' => esc_html__('Icon Color', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .corpix-hero-btn .corpix-btn .btn-icon svg' => 'fill: {{VALUE}}',
                    '{{WRAPPER}} .corpix-hero-btn-02 .corpix-btn .btn-icon svg' => 'fill: {{VALUE}}',
                ],
                'condition' => ['layout_style!' => '5'],
            ]
        );
        $this->end_controls_tab();
        $this->start_controls_tab(
            'tab_text_hover',
            ['label' => esc_html__('Hover', 'corpix-core')]
        );
        $this->add_control(
            'btn_color_hover',
            [
                'label' => esc_html__('Color', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .corpix-hero-btn .corpix-btn:hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .corpix-hero-btn-02 .corpix-btn:hover' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'btn_bg_color_hover',
            [
                'label' => esc_html__('Background Color', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .corpix-hero-btn .corpix-btn:hover' => 'background-color: {{VALUE}}',
                    '{{WRAPPER}} .corpix-hero-btn-02 .corpix-btn:hover' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'btn_icon_color_hover',
            [
                'label' => esc_html__('Icon Color', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .corpix-hero-btn .corpix-btn:hover .btn-icon svg' => 'fill: {{VALUE}}',
                    '{{WRAPPER}} .corpix-hero-btn-02 .corpix-btn:hover .btn-icon svg' => 'fill: {{VALUE}}',
                ],
            ]
        );
        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_responsive_control(
            'button_space',
            [
                'label' => esc_html__( 'Button Spacing', 'corpix-core' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 200,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .corpix-hero-section .corpix-hero-btn' => 'margin-top: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .corpix-hero-section-02 .corpix-hero-btn' => 'margin-top: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .tech-hero-section-3 .hero-content .tpc-btn-wrap' => 'margin-top: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .tech-hero-section-4 .hero-content .tpc-btn-wrap' => 'margin-top: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .tech-hero-section-5 .hero-content .tpc-btn-wrap' => 'margin-top: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .tech-hero-section-6 .hero-content .tpc-btn-wrap' => 'margin-top: {{SIZE}}{{UNIT}};',

                ],
            ]
        );

        $this->end_controls_section();

}

protected function render($instance = []){ 

    $settings = $this->get_settings_for_display();

    $hide_animated_shape = ($settings['hide_animated_shape'] == 'yes')?('hide-animated-shape'):('');

        if ($settings['layout_style'] == '1'): 
            require_once plugin_dir_path(dirname(__FILE__)) . 'widgets/template-part/tpc-hero-1.php';  
        elseif ($settings['layout_style'] == '2'): 
            require_once plugin_dir_path(dirname(__FILE__)) . 'widgets/template-part/tpc-hero-2.php';  
        elseif ($settings['layout_style'] == '3'): 
            require_once plugin_dir_path(dirname(__FILE__)) . 'widgets/template-part/tpc-hero-3.php';  
        elseif ($settings['layout_style'] == '4'): 
            require_once plugin_dir_path(dirname(__FILE__)) . 'widgets/template-part/tpc-hero-4.php';  
        elseif ($settings['layout_style'] == '5'): 
            require_once plugin_dir_path(dirname(__FILE__)) . 'widgets/template-part/tpc-hero-5.php';  
        elseif ($settings['layout_style'] == '6'): 
            require_once plugin_dir_path(dirname(__FILE__)) . 'widgets/template-part/tpc-hero-6.php';  
         endif; 

    }

}

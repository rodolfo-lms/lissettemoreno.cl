<?php
/*
 * This template can be overridden by copying it to yourtheme/corpix-core/elementor/widgets/tpc-Cat-item.php.
*/
namespace TPCAddons\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.

use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;



use Elementor\{Widget_Base, Controls_Manager, Control_Media, Group_Control_Image_Size, Group_Control_Background, Group_Control_Box_Shadow, Group_Control_Border, Group_Control_Typography, Group_Control_Css_Filter, Utils, Embed};

use TPCAddons\Corpix_Global_Variables as Corpix_Globals;

class TPC_service extends Widget_Base
{

    public function get_name()
    {
        return 'tpc-service';
    }

    public function get_title()
    {
        return esc_html__('Service', 'corpix-core');
    }

    public function get_icon()
    {
        return 'tpc-icon eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['tpc-extensions'];
    }

 
protected function register_controls()
{

	// ====== Start Content section ======

    $this->start_controls_section(
        'content_section',
        [
            'label' => __( 'Content', 'plugin-name' ),
            'tab' => Controls_Manager::TAB_CONTENT,
        ]
    );

    $this->add_control(
        'layout_style',
        [
            'label' => __( 'Style', 'corpix-core' ),
            'type' => Controls_Manager::SELECT,
            'default' => '1',
            'options' => [
                '1'   => __( 'Style 1', 'corpix-core' ),
                '2'   => __( 'Style 2', 'corpix-core' ),
                '3'   => __( 'Style 3', 'corpix-core' ),
                '4'   => __( 'Style 4', 'corpix-core' ),
                '5'   => __( 'Style 5', 'corpix-core' ),
            ],
        ]
    );

    $this->add_responsive_control(
        'align',
        [
            'label' => esc_html__( 'Alignment', 'corpix-core' ),
            'type' => Controls_Manager::CHOOSE,
            'options' => [
                'left' => [
                    'title' => esc_html__( 'Left', 'corpix-core' ),
                    'icon' => 'eicon-text-align-left',
                ],
                'center' => [
                    'title' => esc_html__( 'Center', 'corpix-core' ),
                    'icon' => 'eicon-text-align-center',
                ],
                'right' => [
                    'title' => esc_html__( 'Right', 'corpix-core' ),
                    'icon' => 'eicon-text-align-right',
                ],
            ],
            'selectors' => [
                '{{WRAPPER}} .single-item-wrap .single-item' => 'text-align: {{VALUE}};',
                '{{WRAPPER}} .single-item' => 'text-align: {{VALUE}};'
            ],
        ]
    );

	$this->add_control(
		'icon-img',
		[
			'type' => Controls_Manager::MEDIA,
			'label' => esc_html__( 'Choose Image', 'corpix-core' ),
			'default' => [
				'url' => Utils::get_placeholder_image_src(),
			],
			'selector' => '{{WRAPPER}} .elementor-widget-tpc-service .single-item .service-icon .icon-image',
		]
	);


	$this->add_control(
		'title',
		[
			'label' => esc_html__( 'Title', 'corpix-core' ),
			'type' => Controls_Manager::TEXTAREA,
			'dynamic' => [
				'active' => true,
			],
			'placeholder' => esc_html__( 'Enter your title', 'corpix-core' ),
			'default' => esc_html__( 'Digital Marketing', 'corpix-core' ),
			'selector' => '{{WRAPPER}} .elementor-widget-tpc-service .single-item .service-content .title',
			'condition' => [
				'layout_style' => ['1','2','3'],
				
			],
			
		]
	);
	$this->add_control(
		'title_2',
		[
			'label' => esc_html__( 'Title', 'corpix-core' ),
			'type' => Controls_Manager::TEXTAREA,
			'dynamic' => [
				'active' => true,
			],
			'placeholder' => esc_html__( 'Enter your title', 'corpix-core' ),
			'default' => esc_html__( 'providing innovative Website solutions for future.', 'corpix-core' ),
			'selector' => '{{WRAPPER}} .elementor-widget-tpc-service .service-item .service-text .title-2',
			'condition' => [
				'layout_style' => ['4','5'],
				
			],
			
		]
	);

	$this->add_control(
		'description',
		[
			'label' => esc_html__( 'Description', 'corpix-core' ),
			'type' => Controls_Manager::TEXTAREA,
			'dynamic' => [
				'active' => true,
			],
			'placeholder' => esc_html__( 'Enter your title', 'corpix-core' ),
			'default' => esc_html__( 'We can help you channel your potential implementing your idea. We take care of all your needs, crafting specific.', 'corpix-core' ),
			'selector' => '{{WRAPPER}} .elementor-widget-tpc-service .single-item .service-content p.description',
			'condition' => [
				'layout_style' => ['2','3','5'],
				
			],
			
		]
	);

    
    $this->add_control(
        'link',
        [
            'label' => __( 'Link', 'corpix-core' ),
            'type' => Controls_Manager::URL,
            'placeholder' => __( 'https://your-link.com', 'corpix-core' ),
            'show_external' => true,
            'default' => [
                'url' => '#',
            ],
			
        ]
    );

	$this->add_control(
		'link_text',
		[
			'label' => esc_html__( 'Link Text', 'corpix-core' ),
			'type' => Controls_Manager::TEXTAREA,
			'dynamic' => [
				'active' => true,
			],
			'placeholder' => esc_html__( 'Enter your title', 'corpix-core' ),
			'default' => esc_html__( 'Learn More', 'corpix-core' ),
			'condition' => [
				'layout_style' => ['2'],
			],
			
		]
	);

	$this->add_control(
		'icon',
		[
			'label' => esc_html__( 'Icon', 'corpix-core' ),
			'type' => Controls_Manager::ICONS,
			'default' => [
				'value' => 'fas fa-arrow-right',
				'library' => 'fa-solid',
			],

			'condition' => [
				'layout_style' => ['2'],
				
			],
		]
	);
	$this->add_control(
		'add_shape',
		[
			'label' => esc_html__('Corner Shape', 'corpix-core'),
			'type' => Controls_Manager::SWITCHER,
			'label_on' => esc_html__( 'On', 'corpix-core' ),
			'label_off' => esc_html__( 'Off', 'corpix-core' ),
			'return_value' => 'yes',
			'default' => 'yes',
			'condition' => [
				'layout_style' => ['1','2'],
				
			],
		]
	);

	$this->add_control(
        'add_border',
        [
            'label' => esc_html__('Add Border?', 'corpix-core'),
            'type' => Controls_Manager::SWITCHER,
            'default' => 'yes',
            'condition' => [
				'layout_style' => ['5'],
				
			],
        ]
    );


    $this->end_controls_section();

    // ====== Start style section ======



		$this->start_controls_section(
			'icon_background_image',
			[
				'label' => esc_html__( 'Style', 'corpix-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout_style' => ['1','2'],
				],
			]
		);

		  

		$this->add_control(
			'icon__bg_image',
			[
				'type' => Controls_Manager::MEDIA,
				'label' => esc_html__( 'Choose Background Image', 'corpix-core' ),
				'selector' => '{{WRAPPER}} .elementor-widget-tpc-service .single-item .service-icon .icon-bg img',
				'condition' => [
					'layout_style' => ['1','2'],
				],
			]
		);

		
		
		$this->add_control(
			'add_box_shadow',
			[
				'label' => esc_html__('Add Box Shadow?', 'corpix-core'),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'corpix-core' ),
				'label_off' => esc_html__( 'No', 'corpix-core' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => [
					'layout_style' => ['2'],
					
				],
			]
		);

		$this->add_control(
			'add_bg_hover',
			[
				'label' => esc_html__('Add background Hover?', 'corpix-core'),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'corpix-core' ),
				'label_off' => esc_html__( 'No', 'corpix-core' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => [
					'layout_style' => ['2'],
					
				],
			]
		);

		
		$this->end_controls_section();


		$this->start_controls_section(
			'section_style_content',
			[
				'label' => esc_html__( 'Content', 'corpix-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->add_control(
			'description_text',
			[
				'label' => esc_html__( 'Text', 'corpix-core' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
				
        $this->add_control(
			'text_color',
			[
				'label' => esc_html__( 'Text Color', 'corpix-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-item .service-content .description' => 'color: {{VALUE}}',
				],
				'condition' => ['layout_style!' => ['3'],]
			]
		);

		$this->start_controls_tabs(
            'desorption_tab',
            [
				'condition' => ['layout_style' => ['3'],]
			],
        );

        $this->start_controls_tab(
            'description_tab_idle',
            ['label' => esc_html__('Idle', 'corpix-core')]
        );

		$this->add_control(
			'text_color_idle',
			[
				'label' => esc_html__( 'Text Color', 'corpix-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-item.layout-3 .service-content .description' => 'color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_tab();

        $this->start_controls_tab(
            'description_tab_hover',
            ['label' => esc_html__('Hover', 'corpix-core')]
        );

        $this->add_control(
			'text_color_hover',
			[
				'label' => esc_html__( 'Text Color', 'corpix-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-item.layout-3:hover .service-content .description' => 'color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_tab();
        $this->end_controls_tabs();

		$this->add_control(
			'heading_title',
			[
				'label' => esc_html__( 'Title', 'corpix-core' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->start_controls_tabs(
            'tabs_icon2',
            [
				// 'condition' => ['icon_type' => 'font'],
			],
        );

        $this->start_controls_tab(
            'tab_icon_idle2',
            ['label' => esc_html__('Idle', 'corpix-core')]
        );

		$this->add_control(
			'title_color_idle',
			[
				'label' => esc_html__( 'Title Color', 'corpix-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-item .service-content .title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .service-item .service-text .title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .service-item.layout-3 .service-content .title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .service-item.layout-4 .service-text .title-2 a' => 'color: {{VALUE}}',
				],
			]
		);

		

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_icon_hover2',
            ['label' => esc_html__('Hover', 'corpix-core')]
        );

        $this->add_control(
			'title_color_hover',
			[
				'label' => esc_html__( 'Title Hover Color', 'corpix-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-item .service-content .title:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .service-item .service-text .title:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .service-item.layout-3:hover .service-content .title' => 'color: {{VALUE}}',
					'{{WRAPPER}} .service-item.layout-4 .service-text .title-2 a:hover' => 'color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_tab();
        $this->end_controls_tabs();

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'selector' => '{{WRAPPER}} .elementor-widget-tpc-service .single-item .service-content a.title, .elementor-widget-tpc-service .service-item.layout-5 .service-item-wrap .service-text .title, .elementor-widget-tpc-service .service-item.layout-4 .service-text .title-2 a',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
			]
		);

		$this->add_control(
			'section_bg',
			[
				'label' => esc_html__( 'Section Background', 'corpix-core' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		
		$this->start_controls_tabs(
            'tabs_icon',
            [
				// 'condition' => ['icon_type' => 'font'],
				
			],
        );

		
        $this->start_controls_tab(
            'tab_icon_idle',
            ['label' => esc_html__('Idle', 'corpix-core')]
        );

        $this->add_control(
            'section_bg_color_idle',
            [
                'label' => esc_html__('Section Bg Color', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .service-item.layout-1 .single-item' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .service-item.layout-2.service-style' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .service-item.layout-4' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .service-item.layout-5' => 'background-color: {{VALUE}};',
                ],
				'condition' => [
					'layout_style!' => ['3']
				],
            ]
        );

		$this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'section__bg',
                'label' => __( 'Gradient Overlay', 'corpix-core' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .service-item.layout-3',
				'condition' => [
					'layout_style' => ['3']
				],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_icon_hover',
            ['label' => esc_html__('Hover', 'corpix-core')]
        );

        $this->add_control(
            'section_bg_color_hover',
            [
                'label' => esc_html__('Section Bg Hover Color', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .service-item.layout-1 .single-item:hover' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .service-item.layout-2.service-style:hover' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .service-item.layout-4:hover' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .service-item.layout-5:hover' => 'background-color: {{VALUE}};',
                ],
				'condition' => [
					'layout_style!' => ['3']
				],
            ]
        );

		$this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'section__bg_hover',
                'label' => __( 'Gradient Overlay', 'corpix-core' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .service-item.layout-3:hover',
				'condition' => [
					'layout_style' => ['3']
				],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

		$this->add_responsive_control(
            'padding',
            [
                'label' => esc_html__( 'Padding', 'corpix-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .service-item.layout-1 .single-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .service-item.layout-2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .service-item.layout-3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .service-item.layout-4' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .service-item.layout-5 .service-item-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    
                ],
                'separator' => 'before',
            ]
        );


		$this->add_control(
			'icon_space',
			[
				'label' => esc_html__( 'Icon Space', 'corpix-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .service-item.layout-5 .service-item-wrap .service-text' => 'margin-left: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'layout_style' => ['5'],
				],
			]
		);

		$this->add_control(
			'icon_bg',
			[
				'label' => esc_html__('Add Icon Background?', 'corpix-core'),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'corpix-core' ),
				'label_off' => esc_html__( 'No', 'corpix-core' ),
				'return_value' => 'yes',
				'default' => 'yes',
				'condition' => [
					'layout_style' => ['5'],
					
				],
			]
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'link_text_style',
			[
				'label' => esc_html__( 'Link Text Style', 'corpix-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout_style' => ['2']
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'link_text_typography',
				'selector' => '{{WRAPPER}} .service-item.layout-2 .service-content .link-btn',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
			]
		);


		$this->start_controls_tabs(
			'style_tabs'
		);

		$this->start_controls_tab(
            'tab_link_idle',
            ['label' => esc_html__('Idle', 'corpix-core')]
        );

        $this->add_control(
            'link_text_color_idle',
            [
                'label' => esc_html__('Link Text', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .service-item.layout-2 .service-content .link-btn' => 'color: {{VALUE}};',
                ],
				'condition' => [
					'layout_style' => ['2']
				],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_link_hover',
            ['label' => esc_html__('Hover', 'corpix-core')]
        );

        $this->add_control(
            'link_text_color_hover',
            [
                'label' => esc_html__('Link Text', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .service-item.layout-2 .service-content .link-btn:hover' => 'color: {{VALUE}};',
                ],
				'condition' => [
					'layout_style' => ['2']
				],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();


		$this->end_controls_section();

		$this->start_controls_section(
			'arrow_style',
			[
				'label' => esc_html__( 'Arrow', 'corpix-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout_style' => ['1','2','4']
				],
			]
		);


		$this->add_control(
			'arrow_color',
			[
				'label' => esc_html__( 'Color', 'corpix-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .service-item .single-item .service-content i.icon-link' => 'color: {{VALUE}}',
					'{{WRAPPER}} .service-item i.icon-link' => 'color: {{VALUE}}',
					'{{WRAPPER}} .service-item .service-content .link-btn .link-icon' => 'background: {{VALUE}}',
				],
				'default' => '',
				'condition' => [
					'layout_style' => ['1','2','4']
				],
			]
		);

		// $this->add_control(
		// 	'arrow_hover_color',
		// 	[
		// 		'label' => esc_html__( 'Hover Color', 'corpix-core' ),
		// 		'type' => Controls_Manager::COLOR,
		// 		'selectors' => [
		// 			'{{WRAPPER}} .service-item .single-item:hover .service-content i.icon-link' => 'color: {{VALUE}}',
		// 		],
		// 		'default' => '',
		// 		'condition' => [
		// 			'layout_style' => ['1','2','4']
		// 		],
		// 	]
		// );

		$this->end_controls_section();

		$this->start_controls_section(
			'shape_1_style',
			[
				'label' => esc_html__( 'Shape 1', 'corpix-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout_style' => ['1','2']
				],
			]
		);


		$this->add_control(
			'shape_1_color',
			[
				'label' => esc_html__( 'Color', 'corpix-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-widget-tpc-service .single-item .shape-1' => 'color: {{VALUE}}',
					'{{WRAPPER}} .service-item.layout-1 .single-item .shape-1' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .service-item.layout-2 .shape-1' => 'border-color: {{VALUE}}',
				],
				'separator' => 'before',
				'default' => 'star_fontawesome',
				'condition' => [
					'layout_style' => ['1','2']
				],
			]
		);

		$this->add_control(
			'shape_1_hover_color',
			[
				'label' => esc_html__( 'Hover Color', 'corpix-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .elementor-widget-tpc-service .single-item:hover .service-content .icon-link:hover' => 'color: {{VALUE}}',
					'{{WRAPPER}} .service-item.layout-1 .single-item:hover .shape-1' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .service-item.layout-2:hover .shape-1' => 'border-color: {{VALUE}}',
				],
				'condition' => [
					'layout_style' => ['1','2']
				],
			]
		);

		$this->end_controls_section();


}

// ====== Render Here ======


protected function render($instance = []){ 
    $settings = $this->get_settings_for_display();
	
	$add_border_class = ( $settings['add_border'] ? 'add-border' : '');
	$add_hover_class = ( $settings['add_bg_hover'] ? 'add-hover' : '');
	$add_box_shadow_class = ( $settings['add_box_shadow'] ? 'add-box-shadow' : '');
	$add_shape = ( $settings['add_shape'] ? '<div class="shape-1"></div>' : '');
	$icon_background = ( $settings['icon_bg'] ? 'round-bg' : '');

	// var_dump($settings['icon']['value']);

	
	if (!empty($settings['link']['url'])) {
		// link for 1st style
		$this->add_render_attribute('link', 'class', 'single-item');
		$this->add_link_attributes('link', $settings['link']);
		// link for 2nd style
		$this->add_render_attribute('link_style_2', 'class', 'link-btn');
		$this->add_link_attributes('link_style_2', $settings['link']);
		// link fot 3rd style
		$this->add_render_attribute('link_style_3', 'class', 'title');
		$this->add_link_attributes('link_style_3', $settings['link']);
	}

    

if ( $settings['layout_style'] == '1'): // Layout 1 ?>
	<div class="service-item layout-<?php echo esc_attr($settings['layout_style'])?>">
		<?php if (!empty($settings['link']['url'])) echo '<a ', $this->get_render_attribute_string('link'), '>'; ?>
			
			<?php echo $add_shape; ?>
			<div class="service-content">
				<h3 class="title"><?php echo($settings['title']) ?> </h3>
				<i class="icon-link flaticon-right-arrow-1"></i>
			</div>
			<div class="service-icon">
				<img class="icon-image" src="<?php echo esc_url($settings['icon-img']['url']); ?>" alt="">
				<div class="icon-bg"><img src="<?php echo esc_url($settings['icon__bg_image']['url']); ?>" alt=""></div>
			</div>
		<?php if (!empty($settings['link']['url'])) echo '</a>';?>

	</div>

<?php 
	elseif ($settings['layout_style'] == '2'): // Layout 2 ?>

	<div class="service-item layout-<?php echo esc_attr($settings['layout_style'])?> service-style <?php echo $add_hover_class;?> <?php echo $add_box_shadow_class;?>">
		<?php echo $add_shape; ?>
		<div class="service-icon">
			<img class="icon-image" src="<?php echo esc_url($settings['icon-img']['url']); ?>" alt="">
			
			<div class="icon-bg"><img src="<?php echo esc_url($settings['icon__bg_image']['url']); ?>" alt=""></div>
		</div>
		<div class="service-content">
			<h3>
				<?php if (!empty($settings['link']['url'])) echo '<a ', $this->get_render_attribute_string('link_style_3'), '>'; ?>
					<?php echo($settings['title']) ?>
				<?php if (!empty($settings['link']['url'])) echo '</a>';?>
			</h3>
			<p class="description"><?php echo($settings['description']) ?></p>
			<?php if (!empty($settings['link']['url'])) echo '<a ', $this->get_render_attribute_string('link_style_2'), '>'; ?>
				<?php echo($settings['link_text']) ?> 
				<span class="link-icon">
					<i class="<?php echo esc_attr($settings['icon']['value'])?>"></i>
				</span>
			<?php if (!empty($settings['link']['url'])) echo '</a>';?>
		</div>
	</div>

	<?php 
	elseif ($settings['layout_style'] == '3'): // Layout 3 ?>

	<div class="service-item layout-<?php echo esc_attr($settings['layout_style'])?> service-style <?php echo $add_hover_class;?><?php echo $add_box_shadow_class;?>">
		<div class="shape-1"></div>
		<img class="shape-2" src="<?php echo esc_url($settings['section__bg_image']['url']); ?>" alt="">
		<div class="service-icon">
			<img class="icon-image" src="<?php echo esc_url($settings['icon-img']['url']); ?>" alt="">
		</div>
		<div class="service-content">
			<h3>
				<?php if (!empty($settings['link']['url'])) echo '<a ', $this->get_render_attribute_string('link_style_3'), '>'; ?>
					<?php echo($settings['title']) ?>
				<?php if (!empty($settings['link']['url'])) echo '</a>';?>
			</h3>
			<p class="description"><?php echo($settings['description']) ?></p>
		</div>
	</div>

	
	
	<?php elseif ($settings['layout_style'] == '4'): // Layout 4 ?>

		<div class="service-item layout-<?php echo esc_attr($settings['layout_style'])?>">
			<div class="service-icon-1">
				<img class="icon-image" src="<?php echo esc_url($settings['icon-img']['url']); ?>" alt="">
			</div>
			<div class="service-text">
				<h3 class="title-2">
					<a href="#">
						<?php echo($settings['title_2']) ?> 
					</a>
				</h3>
			</div>
			<div class="service-link-icon">
				<i class="icon-link flaticon-right-arrow-1"></i>
			</div>
		</div>

	<?php elseif ($settings['layout_style'] == '5'): // Layout 5 ?>

		<div class="service-item layout-<?php echo esc_attr($settings['layout_style'])?>">
			<div class="service-item-wrap <?php echo $add_border_class; ?>">
				<div class="service-icon <?php echo $icon_background;?>">
					<img class="icon-image" src="<?php echo esc_url($settings['icon-img']['url']); ?>" alt="">
				</div>
				<div class="service-text">
					<h3 class="title"><?php echo($settings['title_2']) ?></h3>
					<p class="description"><?php echo($settings['description']) ?></p>
				</div>
			</div>
		</div>

<?php endif;

}


}
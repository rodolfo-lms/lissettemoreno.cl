<?php
/*
 * This template can be overridden by copying it to yourtheme/corpix-core/elementor/widgets/tpc-cat-item.php.
*/
namespace TPCAddons\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.

use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;



use Elementor\{Widget_Base, Controls_Manager, Control_Media, Group_Control_Image_Size, Group_Control_Background, Group_Control_Box_Shadow, Group_Control_Typography, Group_Control_Border, Utils};

use TPCAddons\Corpix_Global_Variables as Corpix_Globals;

class TPC_Image_Layer extends Widget_Base
{

    public function get_name()
    {
        return 'tpc-image-layer';
    }

    public function get_title()
    {
        return esc_html__('Image Layer', 'corpix-core');
    }

    public function get_icon()
    {
        return 'tpc-icon eicon-image-box';
    }

    public function get_categories()
    {
        return ['tpc-extensions'];
    }

    protected function register_controls()
{

    $this->start_controls_section(
        'content_section',
        [
            'label' => __( 'Content', 'plugin-name' ),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
    );

    $this->add_control(
        'layout_style',
        [
            'label' => __( 'Style', 'corpix-core' ),
            'type' => Controls_Manager::SELECT,
            'default' => '1',
            'options' => [
                '1'   => __( 'Style 1', 'corpix-core' ),
                '2'   => __( 'Style 2', 'corpix-core' ),
                '3'   => __( 'Style 3', 'corpix-core' ),
                '4'   => __( 'Style 4', 'corpix-core' ),
                '5'   => __( 'Style 5', 'corpix-core' ),
            ],
        ]
    );
    

    $this->add_control(
        'image_1',
        [
            'label' => esc_html__( 'Choose Image', 'corpix-core' ),
            'type' => Controls_Manager::MEDIA,
            'separator' => 'after',
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
            // 'condition' => [
			// 	'layout_style!' => ['3'],
				
			// ],
        ]
    );
    $this->add_control(
        'image_2',
        [
            'label' => esc_html__( 'Choose Image', 'corpix-core' ),
            'type' => Controls_Manager::MEDIA,
            'separator' => 'after',
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
            'condition' => [
				'layout_style' => ['3','4'],
				
			],
        ]
    );

    $this->add_control(
        'image_shape',
        [
            'label' => esc_html__( 'Image Shape', 'corpix-core' ),
            'type' => Controls_Manager::MEDIA,
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
            'condition' => [
				'layout_style!' => ['3','4','5'],
				
			],
        ]
    );
    


    $this->end_controls_section();

    // ====== Start style section ======

    
        $this->start_controls_section(
            'shape_style',
            [
                'label' => esc_html__( 'Shape Style', 'corpix-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'shape_position',
            [
                'label' => esc_html__( 'Shape Positioning', 'corpix-core' ),
                'type' => Controls_Manager::HEADING,
            ]
        );
    
        $this->add_control(
			'shape_pos_x',
			[
				'label' => esc_html__( 'Shape Horizontal Position ', 'corpix-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 150,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .corpix-image-layer.style-1 .shape-1' => 'left: {{SIZE}}{{UNIT}};',
				],
                'condition' => [
                    'layout_style' => ['1'],
                    
                ],

			]
		);

        $this->add_control(
			'shape_pos_y',
			[
				'label' => esc_html__( 'Shape Vertical Position ', 'corpix-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 150,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .corpix-image-layer.style-1 .shape-1' => 'top: {{SIZE}}{{UNIT}};',
				],
                'condition' => [
                    'layout_style' => ['1'],
                    
                ],

			]
		);

        
                
        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_image',
            [
                'label' => esc_html__( 'Image Style', 'corpix-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'layout_style!' => ['5'],
                    
                ],
            ]
            
        );
                

        $this->add_control(
			'image_2_pos_x',
			[
				'label' => esc_html__( 'Image Positon Horizontal ', 'corpix-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px','%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 150,
						'step' => 1,
					],
                    
				],

				'selectors' => [
					'{{WRAPPER}} .corpix-image-layer.style-3 .img-layer-sm' => 'right: {{SIZE}}{{UNIT}};',
				],
                'condition' => [
                    'layout_style' => ['3'],
                    
                ],

			]
		);
        $this->add_control(
			'image_2_pos_y',
			[
				'label' => esc_html__( 'Image Positon Vertical ', 'corpix-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 150,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .corpix-image-layer.style-3 .img-layer-sm' => 'top: {{SIZE}}{{UNIT}};',
				],
                'condition' => [
                    'layout_style' => ['3'],
                    
                ],

			]
		);

        $this->add_control(
            'image_border',
            [
                'label' => esc_html__( 'Image Border', 'corpix-core' ),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'selector' => '{{WRAPPER}} .corpix-image-layer.style-3 .img-layer-sm',
                'separator' => 'after',

                'condition' => [
                    'layout_style' => ['3'],
                    
                ],
			]
		);

                

        $this->end_controls_section();

        $this->start_controls_section(
            'solid_shape',
            [
                'label' => esc_html__( 'Solid Shape', 'corpix-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'layout_style' => ['3','5'],
                    
                ],
                
            ]
        );

        $this->add_control(
			'shape_width',
			[
				'label' => esc_html__( 'Shape Width ', 'corpix-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 250,
						'step' => 1,
					],
				],
                'default' => [
					'unit' => 'px',
					'size' => 190,
				],
				'selectors' => [
					'{{WRAPPER}} .corpix-image-layer.style-3 .img-layer.img-layer-big .shape-1' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .corpix-image-layer.style-5 .about-img-5::before' => 'width: {{SIZE}}{{UNIT}};',
				],
                'condition' => [
                    'layout_style' => ['3','5'],
                    
                ],

			]
		);

        $this->add_control(
			'shape_height',
			[
				'label' => esc_html__( 'Shape Height ', 'corpix-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 700,
						'step' => 1,
					],
				],
                'default' => [
					'unit' => 'px',
					'size' => 320,
				],
				'selectors' => [
					'{{WRAPPER}} .corpix-image-layer.style-3 .img-layer.img-layer-big .shape-1' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .corpix-image-layer.style-5 .about-img-5::before' => 'height: {{SIZE}}{{UNIT}};',
				],
                'condition' => [
                    'layout_style' => ['3','5'],
                    
                ],

			]
		);

        $this->add_control(
			'shape_position_x',
			[
				'label' => esc_html__( 'Shape Position X ', 'corpix-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => -60,
						'max' => 150,
						'step' => 1,
					],
				],
                'default' => [
					'unit' => 'px',
					'size' => -45,
				],
				'selectors' => [
					'{{WRAPPER}} .corpix-image-layer.style-3 .img-layer.img-layer-big .shape-1' => 'right: {{SIZE}}{{UNIT}};',
				],
                'condition' => [
                    'layout_style' => ['3'],
                    
                ],

			]
		);

        $this->add_control(
			'shape_position_y',
			[
				'label' => esc_html__( 'Shape Position Y ', 'corpix-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => -60,
						'max' => 150,
						'step' => 1,
					],
				],
                'default' => [
					'unit' => 'px',
					'size' => -55,
				],
				'selectors' => [
					'{{WRAPPER}} .corpix-image-layer.style-3 .img-layer.img-layer-big .shape-1' => 'top: {{SIZE}}{{UNIT}};',
				],
                'condition' => [
                    'layout_style' => ['3'],
                    
                ],

			]
		);



        $this->add_control(
            'solid_shape_color',
            [
                'label' => esc_html__( 'Solid Shape Color', 'corpix-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .corpix-image-layer.style-3 .img-layer.img-layer-big .shape-1' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .corpix-image-layer.style-5 .about-img-5::before' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'layout_style' => ['3','5'],
                    
                ],
            ]
        );



        $this->end_controls_section();


}


protected function render($instance = []){ 
    $settings = $this->get_settings_for_display();
    

        if ( $settings['layout_style'] == '1'): // Layout 1 ?>

            <div class="corpix-image-layer style-<?php echo esc_attr($settings['layout_style'])?>">
                <img class="shape-1" src="<?php echo esc_url($settings['image_shape']['url']); ?>" alt="">
                <div class="about-img image-1">
                    <img src="<?php echo esc_url($settings['image_1']['url']); ?>" alt="">
                    <div class="shape-2"></div>
                </div>
            </div>
                
            <?php 
        
        elseif ($settings['layout_style'] == '2'): ?>

            <div class="corpix-image-layer style-<?php echo esc_attr($settings['layout_style'])?>">
                <div class="about-img-right">
                    <div class="shape-2"></div>
                    <div class="about-img image-2">
                        <img class="image" src="<?php echo esc_url($settings['image_1']['url']); ?>" alt="">
                    </div>
                </div>
            </div>

            <?php 
        
        elseif ($settings['layout_style'] == '3'): ?>

            <div class="corpix-image-layer style-<?php echo esc_attr($settings['layout_style'])?>">
                <div class="img-layer img-layer-big">
                    <div class="shape-1"></div>
                    <img class="image" src="<?php echo esc_url($settings['image_1']['url']); ?>" alt="">
                </div>
                <div class="img-layer img-layer-sm">
                    <img class="image" src="<?php echo esc_url($settings['image_2']['url']); ?>" alt="">
                </div>
            </div>

            <?php 
        
        elseif ($settings['layout_style'] == '4'): ?>

            <div class="corpix-image-layer style-<?php echo esc_attr($settings['layout_style'])?>">
                <div class="img-layer img-layer-big">
                    <img class="image" src="<?php echo esc_url($settings['image_1']['url']); ?>" alt="">
                </div>
                <div class="img-layer img-layer-sm">
                    <div class="shape-1"></div>
                    <img class="image" src="<?php echo esc_url($settings['image_2']['url']); ?>" alt="">
                </div>
            </div>
            
        <?php

        elseif ($settings['layout_style'] == '5'): ?>

            <div class="corpix-image-layer style-<?php echo esc_attr($settings['layout_style'])?>">
                <div class="about-img-5">
                    <img src="<?php echo esc_url($settings['image_1']['url']); ?>" alt="">
                </div>
            </div>
            
        <?php
        
        endif;

}


}
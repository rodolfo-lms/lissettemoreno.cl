<?php
/*
 * This template can be overridden by copying it to yourtheme/corpix-core/elementor/widgets/tpc-cat-item.php.
*/
namespace TPCAddons\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.

use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;



use Elementor\{Widget_Base, Controls_Manager, Control_Media, Group_Control_Image_Size, Group_Control_Background, Group_Control_Box_Shadow, Group_Control_Typography, Utils};

use TPCAddons\Corpix_Global_Variables as Corpix_Globals;

class TPC_Year_Experience extends Widget_Base
{

    public function get_name()
    {
        return 'tpc-year-experience';
    }

    public function get_title()
    {
        return esc_html__('Year Experience', 'corpix-core');
    }

    public function get_icon()
    {
        return 'tpc-icon eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['tpc-extensions'];
    }

    protected function register_controls()
{

    $this->start_controls_section(
        'content_section',
        [
            'label' => __( 'Content', 'plugin-name' ),
            'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
        ]
    );

    $this->add_control(
        'layout_style',
        [
            'label' => __( 'Style', 'corpix-core' ),
            'type' => Controls_Manager::SELECT,
            'default' => '1',
            'options' => [
                '1'   => __( 'Style 1', 'corpix-core' ),
                '2'   => __( 'Style 2', 'corpix-core' ),
                '3'   => __( 'Style 3', 'corpix-core' ),
            ],
        ]
    );


    $this->add_control(
        'year',
        [
            'label' => __( 'Title', 'corpix-core' ),
            'type' => Controls_Manager::TEXT,
            'default' => __( '15', 'corpix-core' ),
            'placeholder' => __( 'Type your year here', 'corpix-core' ),
            'label_block' => true,
            'condition' => [
				'layout_style!' => ['3'],
				
			],
        ]
    );

    $this->add_control(
        'text',
        [
            'label' => __( 'Text', 'corpix-core' ),
            'type' => Controls_Manager::TEXTAREA,
            'default' => __( 'YEARS OF PRACTICAL EXPERIENCE', 'corpix-core' ),
            'placeholder' => __( 'Type your description here', 'corpix-core' ),
            'condition' => [
				'layout_style!' => ['3'],
				
			],
        ]
    );

    $this->add_control(
        'experience_text',
        [
            'label' => __( 'Text', 'corpix-core' ),
            'type' => Controls_Manager::TEXTAREA,
            'default' => __( '10+ Years of Working Experience', 'corpix-core' ),
            'placeholder' => __( 'Type your description here', 'corpix-core' ),
            'condition' => [
				'layout_style' => ['3'],
				
			],
        ]
    );

    $this->add_control(
		'description',
		[
			'label' => esc_html__( 'Description', 'elementor' ),
			'type' => Controls_Manager::TEXTAREA,
			'dynamic' => [
				'active' => true,
			],
			'placeholder' => esc_html__( 'Enter your title', 'elementor' ),
			'default' => esc_html__( 'We can help you channel your potential implementing your idea. We take care of all your needs, crafting specific.', 'elementor' ),
			'selector' => '{{WRAPPER}} .year-experience.style-2 .experience-content p.description',
			'condition' => [
				'layout_style' => ['2'],
				
			],
			
		]
	);

    $this->add_control(
		'link_text',
		[
			'label' => esc_html__( 'Link Text', 'corpix-core' ),
			'type' => Controls_Manager::TEXT,
			'dynamic' => [
				'active' => true,
			],
			'placeholder' => esc_html__( 'Enter your title', 'corpix-core' ),
			'default' => esc_html__( 'Learn More', 'corpix-core' ),
			'condition' => [
				'layout_style' => ['2'],
			],
			
		]
	);

    $this->add_control(
        'add_border',
        [
            'label' => esc_html__('Add Border?', 'corpix-core'),
            'type' => Controls_Manager::SWITCHER,
            'default' => 'yes',
            'condition' => [
				'layout_style' => ['2'],
				
			],
        ]
    );

    $this->add_control(
        'add_bg_shape',
        [
            'label' => esc_html__('Add Backgroung Shape?', 'corpix-core'),
            'type' => Controls_Manager::SWITCHER,
            'default' => 'yes',
            'condition' => [
				'layout_style!' => ['1'],
				
			],
        ]
    );
    

    $this->add_control(
		'icon',
		[
			'label' => esc_html__( 'Icon', 'corpix-core' ),
			'type' => Controls_Manager::ICONS,
			'default' => [
				'value' => 'fas fa-arrow-right',
				'library' => 'fa-solid',
			],

			'condition' => [
				'layout_style' => ['2'],
				
			],
		]
	);

    $this->add_control(
        'icon_image',
        [
            'label' => esc_html__( 'Choose Icon Image', 'corpix-core' ),
            'type' => Controls_Manager::MEDIA,
            'default' => [
                'url' => Utils::get_placeholder_image_src(),
            ],
            'condition' => [
				'layout_style' => ['3'],
				
			],
        ]
    );

    $this->add_control(
        'link',
        [
            'label' => __( 'Link', 'corpix-core' ),
            'type' => Controls_Manager::URL,
            'placeholder' => __( 'https://your-link.com', 'corpix-core' ),
            'show_external' => true,
            'default' => [
                'url' => '#',
            ],
            'condition' => [
				'layout_style' => ['2'],
				
			],
        ]
    );




    $this->end_controls_section();

    // ====== Start style section ======

    
        $this->start_controls_section(
            'section_style_image',
            [
                'label' => esc_html__( 'Background', 'elementor' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'bg_color',
            [
                'label' => esc_html__( 'Background Color', 'corpix-core' ),
                'type' => Controls_Manager::HEADING,
            ]
        );
    
        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'section_background',
                'label' => __( 'Background', 'corpix-core' ),
                'types' => [ 'classic', 'gradient' ],
                'selectors' => [
                    '{{WRAPPER}} .year-experience',
                    '{{WRAPPER}} .year-experience.style-3 .experience',
                ],
            ]
        );

        
        $this->add_control(
            'shape_color',
            [
                'label' => esc_html__( 'Shape Color', 'corpix-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .year-experience.style-2.bg-shape::before' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .year-experience.style-3 .shape-1' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'layout_style!' => ['1'],
                    
                ],
            ]
        );

        $this->add_control(
			'section_width',
			[
				'label' => esc_html__( 'Section Width', 'corpix-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .year-experience.style-1' => 'width: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .year-experience.style-3' => 'max-width: {{SIZE}}{{UNIT}};',
				],
                'condition' => [
                    'layout_style!' => ['2'],
                    
                ],

			]
		);

        
        $this->end_controls_section();

        $this->start_controls_section(
            'section_style_content',
            [
                'label' => esc_html__( 'Content', 'elementor' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        
        $this->add_control(
            'year_style',
            [
                'label' => esc_html__( 'Year Number', 'elementor' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        

        $this->add_control(
            'year_number_color',
            [
                'label' => esc_html__( 'Color', 'elementor' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .year-experience.style-1 .experience-content .number' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .year-experience.style-2 .experience .number' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'year_number_bg_color',
            [
                'label' => esc_html__( 'Number Bg Color', 'elementor' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .year-experience.style-2 .experience .number' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'layout_style' => ['2'],
                    
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'year_typography',
                'selector' => '{{WRAPPER}} .year-experience.style-1 .experience-content .number, {{WRAPPER}} .year-experience.style-2 .experience .number',
            ]
        );

        $this->add_control(
            'title_text',
            [
                'label' => esc_html__( 'Title', 'elementor' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'title_text_color',
            [
                'label' => esc_html__( 'Color', 'elementor' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .year-experience.style-1 .experience-content span.text' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .year-experience.style-2 .experience .text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .year-experience.style-1 .experience-content span.text, {{WRAPPER}} .year-experience.style-2 .experience .text',
            ]
        );

        $this->add_control(
            'description_text',
            [
                'label' => esc_html__( 'Description', 'elementor' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
                'condition' => [
					'layout_style' => ['2']
				],
            ]
        );

        $this->add_control(
            'description_text_color',
            [
                'label' => esc_html__( 'Color', 'elementor' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .year-experience.style-2 .experience-content p.description' => 'color: {{VALUE}};',
                ],
                'condition' => [
					'layout_style' => ['2']
				],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'selector' => '{{WRAPPER}} .year-experience.style-2 .experience-content p.description',
                'condition' => [
					'layout_style' => ['2']
				],
            ]
        );

        $this->add_responsive_control(
            'padding',
            [
                'label' => esc_html__( 'Padding', 'corpix-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .year-experience.style-1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .year-experience.style-2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .year-experience.style-3 .experience' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator' => 'before',
            ]
        );

        

        $this->end_controls_section();


        $this->start_controls_section(
			'link_text_style',
			[
				'label' => esc_html__( 'Link Text Style', 'corpix-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout_style' => ['2']
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'link_text_typography',
				'selector' => '{{WRAPPER}} .year-experience.style-2 .experience-content .link-btn',
				'global' => [
					'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
				],
			]
		);


		$this->start_controls_tabs(
			'style_tabs'
		);

		$this->start_controls_tab(
            'tab_link_idle',
            ['label' => esc_html__('Idle', 'corpix-core')]
        );

        $this->add_control(
            'link_text_color_idle',
            [
                'label' => esc_html__('Link Text', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .year-experience.style-2 .experience-content .link-btn' => 'color: {{VALUE}};',
                ],
				'condition' => [
					'layout_style' => ['2']
				],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_link_hover',
            ['label' => esc_html__('Hover', 'corpix-core')]
        );

        $this->add_control(
            'link_text_color_hover',
            [
                'label' => esc_html__('Link Text', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .year-experience.style-2 .experience-content .link-btn:hover' => 'color: {{VALUE}};',
                ],
				'condition' => [
					'layout_style' => ['2']
				],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();


		$this->end_controls_section();


}


protected function render($instance = []){ 
    $settings = $this->get_settings_for_display();
    
        $add_border_class = ( $settings['add_border'] ? 'add-border' : '');
        $add_background_shape = ( $settings['add_bg_shape'] ? 'bg-shape' : '');
        $add_background_shape_2 = ( $settings['add_bg_shape'] ? '<div class="shape-1"></div>' : '');

        // For Dynamic Link
        if (!empty($settings['link']['url'])) {
            $this->add_render_attribute('link', 'class', 'link-btn');
            $this->add_link_attributes('link', $settings['link']);
        }
    

        if ( $settings['layout_style'] == '1'): // Layout 1 ?>

            <div class="year-experience style-<?php echo esc_attr($settings['layout_style'])?>  ">
                <div class="shape-1"></div>
                <div class="experience-content">
                    <?php if( $settings['year']): ?>
                        <h3 class="number"><?php echo $settings['year']; ?></h3>
                    <?php endif; ?>
                    <?php if( $settings['text']): ?>
                        <span class="text"><?php echo $settings['text']; ?></span>
                    <?php endif; ?>
                </div>
            </div>
        <?php 
        
        elseif ($settings['layout_style'] == '2'): ?>

            <div class="year-experience style-<?php echo esc_attr($settings['layout_style'])?> <?php echo $add_background_shape; ?>">
                <div class="experience">
                    <?php if( $settings['year']): ?>
                        <h3 class="number"><?php echo $settings['year']; ?></h3>
                    <?php endif; ?>
                    <?php if( $settings['text']): ?>
                        <h3 class="text"><?php echo $settings['text']; ?></h3>
                    <?php endif; ?>
                </div>
                <div class="experience-content  <?php echo $add_border_class; ?>">
                    <?php if( $settings['description']): ?>
                        <p class="description"><?php echo($settings['description']) ?></p>
                    <?php endif; ?>
                    <?php if (!empty($settings['link']['url'])) echo '<a ', $this->get_render_attribute_string('link'), '>'; ?>
                        <?php echo($settings['link_text']) ?> 
                        <span class="link-icon">
                            <i class="<?php echo esc_attr($settings['icon']['value'])?>"></i>
                        </span>
                        <?php if (!empty($settings['link']['url'])) echo '</a>';?>
                </div>
            </div>

            <?php 
        
        elseif ($settings['layout_style'] == '3'): ?>

            <div class="year-experience style-<?php echo esc_attr($settings['layout_style'])?>">
                <?php echo $add_background_shape_2; ?>
                <div class="experience">
                    <div class="experience-icon">
                        <img src="<?php echo esc_url($settings['icon_image']['url']); ?>" alt="">
                    </div>
                    <div class="experience-text">
                        <h3 class="title"><?php echo $settings['experience_text']; ?></h3>
                    </div>
                </div>
            </div>
            
        <?php
        
        endif;

}


}
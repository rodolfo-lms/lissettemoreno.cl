<?php
namespace TPCAddons\Widgets;

defined('ABSPATH') || exit; // Abort, If called directly.

use Elementor\{Widget_Base, Controls_Manager, Group_Control_Typography, Repeater, Icons_Manager, Group_Control_Border,Group_Control_Box_Shadow};
use TPCAddons\Corpix_Global_Variables as Corpix_Globals;

/**
 * List widget for Header CPT
 *
 *
 * @category Class
 * @package corpix-core\includes\elementor
 * @author Pixelcurve <help.pixelcurve@gmail.com>
 * @since 1.0.0
 */
class TPC_Category_List extends Widget_Base
{
    public function get_name()
    {
        return 'tpc-category-list';
    }

    public function get_title()
    {
        return esc_html__('Category List', 'corpix-core');
    }

    public function get_icon()
    {
        return 'tpc-icon eicon-icon-box';
    }

    public function get_categories()
    {
        return ['tpc-extensions'];
    }

    protected function register_controls()
    {
        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> GENERAL
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_content_general',
            ['label' => esc_html__('General', 'corpix-core')]
        );

        $this->add_control(
			'icon_hover',
			[
				'label' => esc_html__( 'Hide Icon Until Hover?', 'corpix-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'corpix-core' ),
				'label_off' => esc_html__( 'No', 'corpix-core' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $repeater = new Repeater();

        $repeater->add_control(
            'text',
            [
                'label' => esc_html__('Text', 'corpix-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'dynamic' => ['active' => true],
                'placeholder' => esc_attr__('List Item', 'corpix-core'),
                'default' => esc_html__('List Item', 'corpix-core'),
            ]
        );

        $repeater->add_control(
            'selected_icon_fontawesome',
            [
                'label' => esc_html__('Icon', 'corpix-core'),
                'type' => Controls_Manager::ICONS,
                'fa4compatibility' => 'icon',
                'label_block' => true,
                'default' => [
                    'value' => 'fab fa-wordpress',
                    'library' => 'fa-brands',
                ],
            ]
        );

        $repeater->add_control(
            'link',
            [
                'label' => esc_html__('Link', 'corpix-core'),
                'type' => Controls_Manager::URL,
                'dynamic' => ['active' => true],
                'label_block' => true,
                'placeholder' => esc_attr__('https://your-link.com', 'corpix-core'),
            ]
        );

        $repeater->add_control(
			'active_item',
			[
				'label' => esc_html__( 'Active Item?', 'corpix-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'corpix-core' ),
				'label_off' => esc_html__( 'No', 'corpix-core' ),
				'return_value' => 'yes',
				'default' => 'no',
			]
		);

        $this->add_control(
            'icon_list',
            [
                'label' => '',
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    ['text' => esc_html__('List Item #1', 'corpix-core')],
                    ['text' => esc_html__('List Item #2', 'corpix-core')],
                    ['text' => esc_html__('List Item #3', 'corpix-core')],
                ],
                'title_field' => '{{{ text }}}',
            ]
        );
        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> Style
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style',
            [
                'label' => esc_html__('Style', 'corpix-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'wrapper_border',
				'selector' => '{{WRAPPER}} .tpc-category-list',
			]
		);


        $this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'wrapper_box_shadow',
				'selector' => '{{WRAPPER}} .tpc-category-list',
			]
		);



        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> Content
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_content',
            [
                'label' => esc_html__('Content', 'corpix-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'item_padding',
			[
				'label' => esc_html__( 'Item Padding', 'corpix-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .tpc-category-list .category-list-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->add_control(
			'item_margin',
			[
				'label' => esc_html__( 'Item Margin', 'corpix-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors' => [
					'{{WRAPPER}} .tpc-category-list .category-list-item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->add_control(
			'icon_style',
			[
				'label' => esc_html__( 'Icon Typography', 'corpix-core' ),
				'type' => Controls_Manager::HEADING,
                'separator' => 'before',
			]
		);

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'icon_typography',
                'selector' => '{{WRAPPER}} .tpc-category-list .category-list-item .tpc-header-list-icon',
            ]
        );

        $this->add_control(
			'text_style',
			[
				'label' => esc_html__( 'Text Typography', 'corpix-core' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'text_typography',
                'selector' => '{{WRAPPER}} .tpc-category-list .category-list-item .tpc-header-list-text',
            ]
        );

        $this->start_controls_tabs('text_icon_color_tabs');

        //IDLE
        $this->start_controls_tab(
            'tab_idle',
            ['label' => esc_html__('Idle', 'corpix-core')]
        );

        $this->add_control(
            'text_color_idle',
            [
                'label' => esc_html__('Text Color', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .tpc-category-list .category-list-item .tpc-header-list-text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_color_idle',
            [
                'label' => esc_html__('Icon Color', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .tpc-category-list .category-list-item .tpc-header-list-icon' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'item_bg_color_idle',
            [
                'label' => esc_html__('Item Background Color', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .tpc-category-list .category-list-item' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'border_bottom_color_idle',
            [
                'label' => esc_html__('Border Bottom Color', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .tpc-category-list .category-list-item' => 'border-bottom-color: {{VALUE}} !important;',
                ],
            ]
        );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'list_border',
				'selector' => '{{WRAPPER}} .tpc-category-list .category-list-item',
			]
		);

        $this->end_controls_tab();

        //HOVER
        $this->start_controls_tab(
            'tab_hover',
            ['label' => esc_html__('Hover', 'corpix-core')]
        );

        $this->add_control(
            'text_color_hover',
            [
                'label' => esc_html__('Text Color', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .tpc-category-list .category-list-item:hover .tpc-header-list-text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_color_hover',
            [
                'label' => esc_html__('Icon Color', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .tpc-category-list .category-list-item:hover ..tpc-header-list-icon' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'item_bg_color_hover',
            [
                'label' => esc_html__('Item Background Color', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .tpc-category-list .category-list-item:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'border_bottom_color_hover',
            [
                'label' => esc_html__('Border Bottom Color', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .tpc-category-list .category-list-item:hover' => '    border-bottom-color: {{VALUE}} !important;',
                ],
            ]
        );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'list_border_hover',
				'selector' => '{{WRAPPER}} .tpc-category-list .category-list-item:hover',
			]
		);

        $this->end_controls_tab();

        //ACITVE
        $this->start_controls_tab(
            'tab_active',
            ['label' => esc_html__('Active', 'corpix-core')]
        );

        $this->add_control(
            'text_color_active',
            [
                'label' => esc_html__('Text Color', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .tpc-category-list .category-list-item.active .tpc-header-list-text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_color_active',
            [
                'label' => esc_html__('Icon Color', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .tpc-category-list .category-list-item.active .tpc-header-list-icon' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'item_bg_color_active',
            [
                'label' => esc_html__('Item Background Color', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .tpc-category-list .category-list-item.active' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'border_bottom_color_active',
            [
                'label' => esc_html__('Border Bottom Color', 'corpix-core'),
                'type' => Controls_Manager::COLOR,
                'dynamic' => ['active' => true],
                'selectors' => [
                    '{{WRAPPER}} .tpc-category-list .category-list-item.active' => '    border-bottom-color: {{VALUE}} !important;',
                ],
            ]
        );

        $this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'list_border_active',
				'selector' => '{{WRAPPER}} .tpc-category-list .category-list-item.active',
			]
		);

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->end_controls_section();
        
    }

    public function render()
    {
        $settings = $this->get_settings_for_display();
        $fallback_defaults = [
            'fa fa-check',
            'fa fa-times',
            'fa fa-dot-circle-o',
        ];

        $icon_hover = ($settings['icon_hover'] == 'yes') ? ('icon-hover-visible') : ('');


        $this->add_render_attribute([
            'icon_list' => [
                'class' => [
                    'tpc-category-list',
                ],
            ],
        ]);

        echo '<ul ', $this->get_render_attribute_string('icon_list'), '>';
        foreach ($settings['icon_list'] as $index => $item) :
            $repeater_setting_key = $this->get_repeater_setting_key('text', 'icon_list', $index);

            $active_item = ($item['active_item'] == 'yes') ? ('active') : ('');

            $this->add_render_attribute($repeater_setting_key, 'class', 'tpc-header-list-text');

            $this->add_inline_editing_attributes($repeater_setting_key);
            $migration_allowed = Icons_Manager::is_migration_allowed();

            echo '<li class="category-list-item'.' '.$icon_hover.' '.$active_item.'" >';
            if (!empty($item['link']['url'])) {
                $link_key = 'link_' . $index;

                $this->add_link_attributes($link_key, $item['link']);

                echo '<a ', $this->get_render_attribute_string($link_key), '>';
            }

            echo '<span ', $this->get_render_attribute_string($repeater_setting_key), '>',
            $item['text'],
            '</span>';

            // add old default
            if (!isset($item['icon']) && !$migration_allowed) {
                $item['icon'] = $fallback_defaults[$index] ?? 'fa fa-check';
            }

            $migrated = isset($item['__fa4_migrated']['selected_icon_fontawesome']);
            $is_new = !isset($item['icon']) && $migration_allowed;

            if (
                !empty($item['icon'])
                || (!empty($item['selected_icon_fontawesome']['value']) && $is_new)
            ) {
                echo '<span class="tpc-header-list-icon">';
                if ($is_new || $migrated) {
                    Icons_Manager::render_icon($item['selected_icon_fontawesome'], ['aria-hidden' => 'true']);
                } else {
                    echo '<i class="', esc_attr($item['icon']), '" aria-hidden="true"></i>';
                }
                echo '</span>';
            }


            if (!empty($item['link']['url'])) {
                echo '</a>';
            }

            echo '</li>';
        endforeach;

        echo '</ul>';
    }
}

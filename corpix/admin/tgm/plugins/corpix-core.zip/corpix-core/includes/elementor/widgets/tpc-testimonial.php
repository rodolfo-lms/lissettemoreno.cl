<?php
/*
 * This template can be overridden by copying it to yourtheme/corpix-core/elementor/widgets/tpc-feedback.php.
*/
namespace TPCAddons\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\{Widget_Base, Controls_Manager, Control_Media};
use Elementor\{Group_Control_Border, Group_Control_Box_Shadow, Group_Control_Background, Group_Control_Image_Size, Group_Control_Typography, Icons_Manager};
use Elementor\{Repeater, Utils};
use TPCAddons\Corpix_Global_Variables as Corpix_Globals;
use TPCAddons\Includes\{TPC_Feedback_Settings, TPC_Elementor_Helper};

class TPC_Testimonial extends Widget_Base
{
    public function get_name() {
        return 'tpc-testi';
    }

    public function get_title() {
        return esc_html__('Testimonials', 'corpix-core');
    }

    public function get_icon() {
        return 'tpc-icon eicon-testimonial';
    }

    public function get_script_depends() {
        return [ 'slick' ];
    }

    public function get_categories() {
        return [ 'tpc-extensions' ];
    }

    protected function register_controls()
    {
        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> GENERAL
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_content_general',
            [ 'label' => esc_html__('General', 'corpix-core') ]
        );

        $this->add_control(
            'testi_style',
            [
                'label' => __( 'Style', 'corpix-core' ),
                'type' => Controls_Manager::SELECT,
                'default' => '1',
                'options' => [
                    '1' => esc_html__('1 / One', 'corpix-core'),
                    '2' => esc_html__('2 / Two', 'corpix-core'),
                    '3' => esc_html__('3 / Three', 'corpix-core'),
                ],
            ]
        );

        $this->add_responsive_control(
            'testi_content_align',
            [
                'label' => esc_html__( 'Text Alignment', 'corpix-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'corpix-core' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'corpix-core' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'corpix-core' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .corpix-fixed-style .corpix-testimonial-wrapper>*' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'testi_content_justify',
            [
                'label' => esc_html__( 'Justify Content', 'corpix-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__( 'Left', 'corpix-core' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'corpix-core' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => esc_html__( 'Right', 'corpix-core' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .corpix-fixed-style .corpix-testimonial-wrapper' => 'justify-content: {{VALUE}};',
                ],
            ]
        );
       

        $repeater = new Repeater();
        
        // $repeater->add_group_control(
        //     Group_Control_Image_Size::get_type(),
        //     [
        //         'name' => 'thumb_size',
        //         'default' => 'large',
        //         'separator' => 'none',
        //     ]
        // );

        $repeater->add_control(
            'client_name',
            [
                'label'   => __( 'Name', 'corpix-core' ),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => __('Johan Doe','corpix-core'),

            ]    
        );
        $repeater->add_control(
            'client_designation',
            [
                'label'   => __( 'Designation', 'corpix-core' ),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => __('Managing Director','corpix-core'),
            ]
        );
        // $repeater->add_control(
        //     'client_heading',
        //     [
        //         'label'   => __( 'Heading', 'corpix-core' ),
        //         'type'    => Controls_Manager::TEXT,
        //         'label_block' => true,
        //         'default' => __('They Are Best','corpix-core'),
        //     ]
        // );
        $repeater->add_control(
            'client_say_1',
            [
                'label'   => __( 'Feedback 1st Part', 'corpix-core' ),
                'type'    => Controls_Manager::TEXTAREA,
                'default' => __('Great looking One Pager with clean typography for ','corpix-core'),
            ]
        );
        $repeater->add_control(
            'client_say_2',
            [
                'label'   => __( 'Feedback 2nd Part', 'corpix-core' ),
                'type'    => Controls_Manager::TEXTAREA,
                'default' => __('custom branding ','corpix-core'),
            ]
        );
        $repeater->add_control(
            'client_say_3',
            [
                'label'   => __( 'Feedback 3rd Part', 'corpix-core' ),
                'type'    => Controls_Manager::TEXTAREA,
                'default' => __('and  ','corpix-core'),
            ]
        );
        $repeater->add_control(
            'client_say_4',
            [
                'label'   => __( 'Feedback 4th Part', 'corpix-core' ),
                'type'    => Controls_Manager::TEXTAREA,
                'default' => __('web design studio  ','corpix-core'),
            ]
        );


        $this->add_control(
            'list',
            [
                'label' => esc_html__('Items', 'corpix-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                    'default' => [

                        [
                            'client_name'           => __('James Smith','corpix-core'),
                            'client_designation'    => __( 'CFO Apple Corp','corpix-core' ),
                            'client_say'            => __( 'I believe in lifelong learning and they are a great place to learn from experts. I have learned a lot and recommend it', 'corpix-core' ),
                        ],

                        [
                            'client_name'           => __('Mark Donald','corpix-core'),
                            'client_designation'    => __( 'Manager','corpix-core' ),
                            'client_say'            => __( 'Lorem ipsum dolor sit amet consectetur adipisicing elit sed do eiusmod tempor incididunt labore Lorem ipsum', 'corpix-core' ),
                        ],

                        [
                            'client_name'           => __('John Dowson','corpix-core'),
                            'client_designation'    => __( 'Developer','corpix-core' ),
                            'client_say'            => __( 'I believe in lifelong learning and they are a great place to learn from experts. I have learned a lot and recommend it', 'corpix-core' ),
                        ],
                    ],
                    'title_field' => '{{{ client_name }}}',
            ]
        );

        $this->add_control(
            'author_image',
            [
                'label' => esc_html__('Author Image', 'corpix-core'),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
                'default' => [ 'url' => Utils::get_placeholder_image_src() ],
                'condition' => [
                    'testi_style' => ['2']
                ],
                
            ]
        );
       

        $this->end_controls_section();


       
        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> CAROUSEL OPTIONS
        /*-----------------------------------------------------------------------------------*/
            $this->start_controls_section(
                'tpc_carousel_section',
                ['label' => esc_html__('Carousel Options', 'corpix-core')]
            );

            $this->add_control(
                'autoplay',
                [
                    'label' => esc_html__('Autoplay', 'corpix-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__('On', 'corpix-core'),
                    'label_off' => esc_html__('Off', 'corpix-core'),
                ]
            );

            $this->add_control(
                'autoplay_speed',
                [
                    'label' => esc_html__('Autoplay Speed', 'corpix-core'),
                    'type' => Controls_Manager::NUMBER,
                    'min' => 1,
                    'step' => 1,
                    'default' => '5000',
                    'condition' => [
                        'autoplay' => 'yes',
                    ],
                ]
            );
            $this->add_control(
                'infinite',
                [
                    'label' => esc_html__('Infinite Loop Sliding', 'corpix-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__('On', 'corpix-core'),
                    'label_off' => esc_html__('Off', 'corpix-core'),
                    'return_value' => 'yes',
                    'default' => 'yes'
                ]
            );
            $this->add_control(
                'centeredmode',
                [
                    'label' => esc_html__('Centered Slides', 'corpix-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__('On', 'corpix-core'),
                    'label_off' => esc_html__('Off', 'corpix-core'),
                    'return_value' => 'yes',
                    'default' => ''
                ]
            );
            $this->add_control(
                'coverflow_effect',
                [
                    'label' => esc_html__('Coverflow Effect', 'corpix-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__('On', 'corpix-core'),
                    'label_off' => esc_html__('Off', 'corpix-core'),
                ]
            );

            $this->add_control(
                'tablet_item',
                [
                    'label' => esc_html__('Tablet Device Item', 'corpix-core'),
                    'type' => Controls_Manager::NUMBER,
                    'default' => '1',
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'tablet_width',
                [
                    'label' => esc_html__('Tablet Device Width', 'corpix-core'),
                    'type' => Controls_Manager::NUMBER,
                    'default' => '768',
                ]
            );
            $this->add_control(
                'mobile_item',
                [
                    'label' => esc_html__('Mobile Device Item', 'corpix-core'),
                    'type' => Controls_Manager::NUMBER,
                    'default' => '1',
                    'separator' => 'before',
                ]
            );      
            $this->add_control(
                'mobile_width',
                [
                    'label' => esc_html__('Mobile Device Width', 'corpix-core'),
                    'type' => Controls_Manager::NUMBER,
                    'default' => '480',
                ]
            );    
            $this->add_responsive_control(
                'space_between',
                [
                    'label' => esc_html__('Space Between', 'corpix-core'),
                    'type' => Controls_Manager::NUMBER,
                    'default' => '20',
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'use_prev_next',
                [
                    'label' => esc_html__('Add Prev/Next buttons', 'corpix-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__('On', 'corpix-core'),
                    'label_off' => esc_html__('Off', 'corpix-core'),
                    'separator' => 'before',
                    'return_value' => 'yes',
                    'default' => '',
                ]
            );
         
            $this->add_control(
                'use_pagination',
                [
                    'label' => esc_html__('Add Pagination', 'corpix-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__('On', 'corpix-core'),
                    'label_off' => esc_html__('Off', 'corpix-core'),
                    'separator' => 'before',
                    'return_value' => 'yes',
                    'default' => 'yes',
                    ]
            );
          $this->add_control(
                'pag_type',
                [
                    'label' => esc_html__('Pagination Type', 'corpix-core'),
                    'type' => 'tpc-radio-image',
                    'condition' => [
                        'use_pagination' => 'yes',
                        'testi_style' => ['1', '2', '3']
                    ],
                    'options' => [
                        'circle' => [
                            'title' => esc_html__('Circle', 'corpix-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_circle.png',
                        ],
                        'circle_border' => [
                            'title' => esc_html__('Empty Circle', 'corpix-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_circle_border.png',
                        ],
                        'square' => [
                            'title' => esc_html__('Square', 'corpix-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_square.png',
                        ],
                        'square_border' => [
                            'title' => esc_html__('Empty Square', 'corpix-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_square_border.png',
                        ],
                        'line' => [
                            'title' => esc_html__('Line', 'corpix-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_line.png',
                        ],
                        'line_circle' => [
                            'title' => esc_html__('Line - Circle', 'corpix-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_line_circle.png',
                        ],
                    ],
                    'default' => 'circle',
                ]
            );

            $this->add_responsive_control(
                'pagination_align',
                [
                    'label' => esc_html__( 'Alignment', 'corpix-core' ),
                    'type' => Controls_Manager::CHOOSE,
                    'options' => [
                        'left' => [
                            'title' => esc_html__( 'Left', 'corpix-core' ),
                            'icon' => 'eicon-text-align-left',
                        ],
                        'center' => [
                            'title' => esc_html__( 'Center', 'corpix-core' ),
                            'icon' => 'eicon-text-align-center',
                        ],
                        'right' => [
                            'title' => esc_html__( 'Right', 'corpix-core' ),
                            'icon' => 'eicon-text-align-right',
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .corpix-fixed-style .corpix-testimonial-wrapper .corpix-slider-wrapper .swiper-pagination' => 'text-align: {{VALUE}};',
                    ],
                    'condition' => [
                        'use_pagination' => 'yes',
                        'testi_style' => ['1', '2']
                    ],
                ]
            );

            $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  STYLES -> Style
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_style',
            [
                'label' => esc_html__('Styles', 'corpix-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'testi_style' => ['1','3'],
                ],
            ]
        );
        
        $this->add_control(
            'quote_color',
            [
                'label' => __( 'Quote Color', 'corpix-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .corpix-fixed-style .testimonial-quote-fixed .quote svg' => 'fill: {{VALUE}};',
                    '{{WRAPPER}} .corpix-feedback-style-3 .single-testimonial .quote svg g' => 'fill: {{VALUE}};',
                ],
                'condition' => [
                    'testi_style' => ['1','3'],
                ],
            ]
        );
        $this->add_control(
            'quote_bg_color',
            [
                'label' => __( 'Quote Background Color', 'corpix-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .corpix-fixed-style .testimonial-quote-fixed .svg-shape svg' => 'fill: {{VALUE}};',
                    '{{WRAPPER}} .corpix-feedback-style-3 .single-testimonial .svg-shape-02 svg' => 'fill: {{VALUE}};',
                ],
                'condition' => [
                    'testi_style' => ['1','3'],
                ],
            ]
        );
        $this->add_control(
            'quote_bg_border_color',
            [
                'label' => __( 'Quote Border Color', 'corpix-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .corpix-fixed-style .testimonial-quote-fixed .svg-shape::after' => 'border-color: {{VALUE}};',
                    '{{WRAPPER}} .corpix-feedback-style-3 .single-testimonial .svg-shape-02::after' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'testi_style' => ['1','3'],
                ],
            ]
        );
                  
        $this->end_controls_section();
       

    // Style Testimonial name style start

        $this->start_controls_section(
            'client_name_style',
            [
                'label'     => __( 'Name', 'corpix-core' ),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'client_name_color',
            [
                'label' => __( 'Color', 'corpix-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .corpix-fixed-style .corpix-slider-wrapper .single-testimonial .testimonial-content .name' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .corpix-feedback-style-3 .single-testimonial .testimonial-content .name' => 'color: {{VALUE}};',
                ],
            ]
        );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'client_name_typography',
                    'global' => [
                        'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
                    ],
                    'selector' => '{{WRAPPER}} .corpix-fixed-style .corpix-slider-wrapper .single-testimonial .testimonial-content .name, .corpix-feedback-style-3 .single-testimonial .testimonial-content .name',
                ]
            );


        $this->end_controls_section(); // Style Testimonial name style end


        // Style Testimonial designation style start
        $this->start_controls_section(
            'client_designation_style',
            [
                'label'     => __( 'Degree', 'corpix-core' ),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );
            
            $this->add_control(
                'client_degree_color',
                [
                    'label' => __( 'Color', 'corpix-core' ),
                    'type' => Controls_Manager::COLOR,
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .corpix-fixed-style .corpix-slider-wrapper .single-testimonial .testimonial-content .designation' => 'color: {{VALUE}};',
                        '{{WRAPPER}} .corpix-feedback-style-3 .single-testimonial .testimonial-content .designation' => 'color: {{VALUE}};',
                    ],
                ]
            );

            $this->add_group_control(
                Group_Control_Typography::get_type(),
                [
                    'name' => 'client_degree_typography',
                    'global' => [
                        'default' => Global_Typography::TYPOGRAPHY_TEXT,
                    ],
                    'selector' => '{{WRAPPER}} .corpix-fixed-style .corpix-slider-wrapper .single-testimonial .testimonial-content .designation, .corpix-feedback-style-3 .single-testimonial .testimonial-content .designation',
                ]
            );


        $this->end_controls_section(); // Style Testimonial designation style end


        // Style Testimonial designation style start
        $this->start_controls_section(
            'clientsay_style',
            [
                'label'     => __( 'Client say', 'corpix-core' ),
                'tab'       => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
			'clientsay_padding',
			[
				'label' => esc_html__( 'Padding', 'corpix-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .corpix-fixed-style .corpix-slider-wrapper .single-testimonial .testimonial-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
        
          
        $this->add_control(
            'clientsay_color_1',
            [
                'label' => __( 'Color 1', 'corpix-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .corpix-fixed-style .corpix-slider-wrapper .single-testimonial .testimonial-content .testimonial-text' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .corpix-feedback-style-3 .single-testimonial .testimonial-content .testimonial-text' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
            'clientsay_color_2',
            [
                'label' => __( 'Color 2', 'corpix-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .corpix-fixed-style .corpix-slider-wrapper .single-testimonial .testimonial-content .testimonial-text span' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .corpix-feedback-style-3 .single-testimonial .testimonial-content .testimonial-text span' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'corpix_feedback_clientsay_typography',
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_TEXT,
                ],
                'selector' => '{{WRAPPER}} .corpix-fixed-style .corpix-slider-wrapper .single-testimonial .testimonial-content .testimonial-text, .corpix-fixed-style .corpix-slider-wrapper .single-testimonial .testimonial-content .testimonial-text span, .corpix-feedback-style-2 .corpix-slider-wrapper .single-testimonial .testimonial-content .testimonial-text span, .corpix-feedback-style-3 .single-testimonial .testimonial-content .testimonial-text span, .corpix-feedback-style-3 .single-testimonial .testimonial-content .testimonial-text',
            ]
        );


        $this->end_controls_section(); // Style Testimonial designation style end



        // Style arrow style start
        $this->start_controls_section(
            'cat_carousel_arrow_style',
            [
                'label'     => __('Prev/Next buttons', 'corpix-core'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'use_prev_next' => 'yes',
                ],
            ]
        );
        $this->add_control(
            'cat_carousel_arrow_color',
            [
                'label'     => __('Color', 'corpix-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#5A5A5A',
                'selectors' => [
                    '{{WRAPPER}} .corpix__carousel .swiper-button-next:after, .corpix__carousel .swiper-button-prev:after' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'cat_carousel_arrow_fontsize',
            [
                'label'      => __('Arrow Size', 'corpix-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 50,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .corpix__carousel .swiper-button-next:after, .corpix__carousel .swiper-button-prev:after' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'arrow_bg_color',
            [
                'label'     => __('Background Color', 'corpix-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .corpix__carousel .swiper-button-next, .corpix__carousel .swiper-button-prev' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'cat_carousel_arrow_border',
                'label'    => __('Border', 'corpix-core'),
                'selector' => '{{WRAPPER}} .corpix__carousel .swiper-button-next, .corpix__carousel .swiper-button-prev',
            ]
        );

        $this->add_responsive_control(
            'cat_carousel_arrow_border_radius',
            [
                'label'     => __('Border Radius', 'corpix-core'),
                'type'      => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .corpix__carousel .swiper-button-next, .corpix__carousel .swiper-button-prev' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'arrow_box_shadow',
                'selector' => '{{WRAPPER}} .corpix__carousel .swiper-button-next, .corpix__carousel .swiper-button-prev',
            ]
        );


        $this->end_controls_section(); // Style cat box arrow style end

        // Style cat box Dots style start
        $this->start_controls_section(
            'cat_carousel_dots_style',
            [
                'label'     => __('Pagination', 'corpix-core'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'use_pagination' => 'yes',
                ],
            ]
        );

        $this->start_controls_tabs('cat_carousel_dots_style_tabs');

        // Normal tab Start
        $this->start_controls_tab(
            'cat_carousel_dots_style_normal_tab',
            [
                'label' => __('Normal', 'corpix-core'),
            ]
        );

        $this->add_control(
            'dot_color',
            [
                'label'     => __('Color', 'corpix-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .corpix__carousel .swiper-pagination .swiper-pagination-bullet' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .corpix__carousel.pagination_square_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet:before' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .corpix__carousel.pagination_circle_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet:before' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'cat_carousel_dots_height',
            [
                'label'      => __('Size', 'corpix-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 30,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .corpix__carousel .swiper-pagination .swiper-pagination-bullet' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'pag_type' => 'circle',
                ],
            ]
        );

        $this->add_responsive_control(
            'cat_carousel_dots_space',
            [
                'label'      => __('Space Between', 'corpix-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 30,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => '5',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .corpix__carousel .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet' => 'margin-left: {{SIZE}}{{UNIT}}; margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'cat_carousel_dots_position',
            [
                'label'      => __('Position X', 'corpix-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => -300,
                        'max'  => 300,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => -60,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .corpix__carousel .swiper-pagination' => 'bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'cat_carousel_dots_position_y',
            [
                'label'      => __('Position Y', 'corpix-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => -700,
                        'max'  => 700,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .corpix__carousel .swiper-pagination' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_tab(); // Normal tab end

        // Hover tab Start
        $this->start_controls_tab(
            'cat_carousel_dots_style_hover_tab',
            [
                'label' => __('Active', 'corpix-core'),
            ]
        );
        $this->add_control(
            'dot_hover_color',
            [
                'label'     => __('Active Color', 'corpix-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .corpix__carousel .swiper-pagination .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .corpix__carousel.pagination_square_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet.swiper-pagination-bullet-active:before' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .corpix__carousel.pagination_square_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'border-color: {{VALUE}};',
                    '{{WRAPPER}} .corpix__carousel.pagination_circle_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet.swiper-pagination-bullet-active:before' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .corpix__carousel.pagination_circle_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab(); // Hover tab end

        $this->end_controls_tabs();

        $this->end_controls_section(); // Style cat box dots style end


        // Style Testimonial name style start

        $this->start_controls_section(
            'image_style',
            [
                'label'     => __( 'Image', 'corpix-core' ),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'testi_style' => ['2']
                ],
            ]
        );


        $this->add_responsive_control(
			'image_bottom_space',
			[
				'label' => esc_html__( 'Image Bottom Space', 'corpix-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .testimonial-img-fixed .testi-img' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
			]
		);


        $this->end_controls_section(); // Style Testimonial name style end

    }

    protected function render()
    {
        $id = $this->get_id();
        $settings = $this->get_settings_for_display();

        $migrated = isset( $settings['__fa4_migrated']['selected_icon'] );
        $is_new = empty( $settings['icon'] ) && Icons_Manager::is_migration_allowed();

        if ( empty( $settings['icon'] ) && ! Icons_Manager::is_migration_allowed() ) {
            // add old default
            $settings['icon'] = 'fa fa-star';
        }

?>


        <div class="corpix__carousel pagination_<?php echo esc_attr($settings['pag_type']) ?> corpix-fixed-style corpix-feedback-style-<?php echo $settings['testi_style']; ?>">  



            <?php if ($settings['testi_style'] == '1'): ?>

                <div class="corpix-testimonial-wrapper">    
                    <div class="testimonial-quote-fixed">
                        <div class="svg-shape">
                            <svg xmlns="http://www.w3.org/2000/svg">
                                <path d="M236.487,317.317 C152.817,317.317 46.461,317.317 46.461,317.317 C20.801,317.317 0.0,296.546 0.0,270.923 L0.0,46.381 C0.0,20.759 20.801,0.11 46.461,0.11 L335.449,0.11 C361.109,0.11 381.910,20.759 381.910,46.381 L381.910,270.923 C381.910,296.546 361.109,317.317 335.449,317.317 C335.449,317.317 317.13,317.317 289.453,317.317 C289.453,317.317 262.970,333.945 279.696,359.999 L236.487,317.317 Z"></path>
                            </svg>
                        </div>
                        <div class="quote">
                            <svg xmlns="http://www.w3.org/2000/svg" version="1.0" viewBox="0 0 250.000000 192.000000" preserveAspectRatio="xMidYMid meet">

                                <g transform="translate(0.000000,192.000000) scale(0.100000,-0.100000)" stroke="none">
                                <path d="M502 1909 c-227 -34 -419 -208 -477 -434 -71 -278 90 -584 360 -681 91 -33 139 -39 159 -19 37 37 16 61 -75 86 -90 25 -147 57 -216 122 -104 99 -153 210 -153 351 0 105 26 192 81 275 51 77 105 123 194 167 180 88 392 58 539 -77 152 -139 188 -297 126 -555 -82 -344 -225 -686 -406 -975 -33 -52 -63 -103 -67 -113 -7 -17 23 -56 43 -56 20 0 55 47 132 177 186 314 315 634 393 981 40 176 32 305 -25 427 -107 225 -361 360 -608 324z"/>
                                <path d="M1832 1909 c-227 -34 -419 -208 -477 -434 -71 -278 90 -584 360 -681 91 -33 139 -39 159 -19 37 38 17 60 -82 88 -169 49 -299 175 -346 336 -23 77 -21 204 4 284 24 77 85 173 143 222 64 55 171 103 257 116 183 28 376 -62 481 -223 81 -127 89 -267 26 -508 -88 -338 -221 -647 -400 -932 -42 -67 -65 -112 -61 -122 8 -22 39 -37 58 -30 40 15 269 430 345 624 113 287 191 582 191 723 0 339 -316 606 -658 556z"/>
                                </g>
                            </svg>
                        </div>
                    </div>

                    <div class="corpix-slider-wrapper">

                        <div class="corpix_feedback_id<?php echo $id; ?>">
                            <div class="swiper-wrapper">

                                <?php      
                                    foreach ($settings['list'] as $index => $item) {

                                ?> 
                                    <div class="swiper-slide">
                                        <!-- Testimonial Start -->
                                        <div class="single-testimonial">
                                            <div class="testimonial-content">
                                                <?php if ($item['client_say_1'] || $item['client_say_2'] || $item['client_say_3'] || $item['client_say_4']):?>
                                                    <h3 class="testimonial-text">
                                                        <?php echo $item['client_say_1']; ?>
                                                        <?php echo ($item['client_say_2']) ? ('<span>'.$item['client_say_2'].'</span>') : ('');?>                                                 
                                                        <?php echo ($item['client_say_3']) ? ($item['client_say_3']) : ('');?> 
                                                        <?php echo ($item['client_say_4']) ? ('<span>'.$item['client_say_4'].'</span>') : ('');?>
                                                    </h3>
                                                <?php endif ?>
                                                <h3 class="name"><?php echo $item['client_name']; ?></h3>
                                                <p class="designation"><?php echo $item['client_designation']; ?></p>
                                            </div>
                                        </div>
                                        <!-- Testimonial End -->
                                    </div>

                                    <?php

                                    } ?>

                            </div>
                                <!-- If we need navigation buttons -->
                                <?php if ($settings['use_prev_next']): ?>
                                    <div class="swiper-button-prev"></div>
                                    <div class="swiper-button-next"></div>
                                <?php endif ?>
                                <?php if ($settings['use_pagination']): ?>
                                    <div class="swiper-pagination"></div>
                                <?php endif ?>
                       
                        </div> 
                    </div>
                </div>

            <?php endif; ?>


            <?php if ($settings['testi_style'] == '2'): ?>

            <div class="corpix-testimonial-wrapper">    
                <div class="testimonial-img-fixed">
                    <div class="testi-img">
                        <img src="<?php echo esc_url($settings['author_image']['url'])?>" alt="">
                    </div>
                </div>

                <div class="corpix-slider-wrapper">

                    <div class="corpix_feedback_id<?php echo $id; ?>">
                        <div class="swiper-wrapper">

                            <?php      
                                foreach ($settings['list'] as $index => $item) {

                            ?> 
                                <div class="swiper-slide">
                                    <!-- Testimonial Start -->
                                    <div class="single-testimonial">
                                        <div class="testimonial-content">
                                            <?php if ($item['client_say_1'] || $item['client_say_2'] || $item['client_say_3'] || $item['client_say_4']):?>
                                                <h3 class="testimonial-text">
                                                    <?php echo $item['client_say_1']; ?>
                                                    <?php echo ($item['client_say_2']) ? ('<span>'.$item['client_say_2'].'</span>') : ('');?>                                                 
                                                    <?php echo ($item['client_say_3']) ? ($item['client_say_3']) : ('');?> 
                                                    <?php echo ($item['client_say_4']) ? ('<span>'.$item['client_say_4'].'</span>') : ('');?>
                                                </h3>
                                            <?php endif ?>
                                            <h3 class="name"><?php echo $item['client_name']; ?></h3>
                                            <p class="designation"><?php echo $item['client_designation']; ?></p>
                                        </div>
                                    </div>
                                    <!-- Testimonial End -->
                                </div>

                                <?php

                                } ?>

                        </div>
                            <!-- If we need navigation buttons -->
                            <?php if ($settings['use_prev_next']): ?>
                                <div class="swiper-button-prev"></div>
                                <div class="swiper-button-next"></div>
                            <?php endif ?>
                            <?php if ($settings['use_pagination']): ?>
                                <div class="swiper-pagination"></div>
                            <?php endif ?>
                
                    </div> 
                </div>
            </div>

            <?php endif; ?>

         <?php if ($settings['testi_style'] == '3'): ?>

         <div class="corpix_feedback_id<?php echo $id; ?>">

            <div class="swiper-wrapper">

            <?php      
                    foreach ($settings['list'] as $index => $item) {

                ?> 
                        <div class="swiper-slide">
                            <!-- Testimonial Start -->

                                <div class="single-testimonial">
                                    <!-- Testimonial Quote Start  -->
                                    <div class="testimonial-quote">
                                        <div class="svg-shape-02">
                                            <svg xmlns="http://www.w3.org/2000/svg">
                                                <path d="M95.873,129.606 C61.953,129.606 18.835,129.606 18.835,129.606 C8.432,129.606 0.0,121.141 0.0,110.700 L0.0,19.198 C0.0,8.756 8.432,0.292 18.835,0.292 L135.993,0.292 C146.395,0.292 154.828,8.756 154.828,19.198 L154.828,110.700 C154.828,121.141 146.395,129.606 135.993,129.606 C135.993,129.606 128.518,129.606 117.345,129.606 C117.345,129.606 106.609,136.382 113.390,146.999 L95.873,129.606 Z"></path>
                                            </svg>
                                        </div>
                                        <div class="quote">
                                            <svg xmlns="http://www.w3.org/2000/svg" version="1.0" width="101.000000px" height="78.000000px" viewBox="0 0 101.000000 78.000000" preserveAspectRatio="xMidYMid meet">
                                                <g transform="translate(0.000000,78.000000) scale(0.100000,-0.100000)" fill="#000000" stroke="none">
                                                    <path d="M160 767 c-57 -19 -125 -93 -146 -159 -15 -49 -16 -65 -5 -111 21 -94 89 -166 174 -182 60 -12 51 12 -18 45 -86 41 -118 87 -123 174 -3 72 19 120 81 169 30 25 49 32 97 35 102 7 183 -50 210 -149 23 -83 -59 -332 -166 -510 -37 -62 -41 -79 -19 -79 8 0 33 31 56 70 96 162 174 395 166 497 -11 145 -167 247 -307 200z" />
                                                    <path d="M695 765 c-97 -38 -164 -151 -150 -254 13 -96 102 -192 180 -195 48 -1 48 16 -2 34 -99 37 -148 109 -141 209 10 140 155 223 284 161 66 -32 104 -95 104 -171 0 -101 -70 -305 -155 -450 -48 -81 -53 -99 -31 -99 29 0 137 213 184 360 52 163 52 234 2 313 -55 87 -179 128 -275 92z" />
                                                </g>
                                            </svg>
                                        </div>
                                    </div>
                                    <!-- Testimonial Quote End  -->
                                    <div class="testimonial-content">
                                            <?php if ($item['client_say_1'] || $item['client_say_2'] || $item['client_say_3'] || $item['client_say_4']):?>
                                                <h3 class="testimonial-text">
                                                    <?php echo $item['client_say_1']; ?>
                                                    <?php echo ($item['client_say_2']) ? ('<span>'.$item['client_say_2'].'</span>') : ('');?>                                                 
                                                    <?php echo ($item['client_say_3']) ? ($item['client_say_3']) : ('');?> 
                                                    <?php echo ($item['client_say_4']) ? ('<span>'.$item['client_say_4'].'</span>') : ('');?>
                                                </h3>
                                            <?php endif ?>
                                        <h3 class="name"><?php echo $item['client_name']; ?></h3>
                                        <p class="designation"><?php echo $item['client_designation']; ?></p>
                                    </div>
                                </div>
                            <!-- Testimonial End -->
                        </div>

                    <?php

                    } ?>
                </div>
                
                    <!-- If we need navigation buttons -->
                    <?php if ($settings['use_prev_next']): ?>
                        <div class="swiper-button-prev"></div>
                        <div class="swiper-button-next"></div>
                    <?php endif ?>
                    <?php if ($settings['use_pagination']): ?>
                        <div class="swiper-pagination"></div>
                    <?php endif ?>

        </div>
        <?php endif ?>
</div>   



<script>
jQuery(document).ready(function() {
    new Swiper('.corpix_feedback_id<?php echo $id; ?>', {
        <?php if ($settings['infinite']): ?>
            loop: true,
        <?php endif ?>        
        <?php if ($settings['centeredmode']): ?>
           centeredSlides: true,
        <?php endif ?>
          
        <?php if ($settings['autoplay']): ?>
          autoplay: {
            delay: <?php echo esc_attr($settings['autoplay_speed']); ?>,
          },
        <?php endif ?>
          pagination: {
            el: ".swiper-pagination",
            clickable: true,
          },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev"
        },
        <?php if (!$settings['testi_style'] == '4' || !$settings['testi_style'] == '5' && $settings['coverflow_effect']): ?>   
            effect: 'coverflow',
            coverflowEffect: {
                rotate: 30,
                slideShadows: false,
            },
        <?php elseif ($settings['testi_style'] == '40' || $settings['testi_style'] == '50'): ?>   
          fadeEffect: { crossFade: true },
          effect: "fade",
        <?php endif ?>

        breakpoints: {
            1200: {
                slidesPerView: 1,
                spaceBetween: <?php echo $settings['space_between'] ?>
            },
            <?php echo $settings['tablet_width'] ?>: {
                slidesPerView:1,
                spaceBetween: <?php echo $settings['space_between'] ?>
            },
            <?php echo $settings['mobile_width'] ?>: {
                slidesPerView: 1,
                spaceBetween: <?php echo $settings['space_between'] ?>
            }
        }
    });
});
</script>
<?php

    }

}

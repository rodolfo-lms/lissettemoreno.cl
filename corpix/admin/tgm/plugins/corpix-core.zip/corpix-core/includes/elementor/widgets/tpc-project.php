<?php
/*
 * This template can be overridden by copying it to yourtheme/corpix-core/elementor/widgets/tpc-feedback.php.
*/
namespace TPCAddons\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\{Widget_Base, Controls_Manager, Control_Media};
use Elementor\{Group_Control_Border, Group_Control_Box_Shadow, Group_Control_Background, Group_Control_Image_Size, Group_Control_Typography};
use Elementor\{Repeater, Utils};
use TPCAddons\Corpix_Global_Variables as Corpix_Globals;
use TPCAddons\Includes\{TPC_Feedback_Settings, TPC_Elementor_Helper};

class TPC_Project extends Widget_Base
{
    public function get_name() {
        return 'tpc-project-carousel';
    }

    public function get_title() {
        return esc_html__('Project', 'corpix-core');
    }

    public function get_icon() {
        return 'tpc-icon eicon-gallery-grid';
    }

    // public function get_script_depends() {
    //     return [ 'slick' ];
    // }

    public function get_categories() {
        return [ 'tpc-extensions' ];
    }

   protected function register_controls()
    {
        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> GENERAL
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_content_general',
            [ 'label' => esc_html__('General', 'corpix-core') ]
        );

        $this->add_responsive_control(
            'item_grid',
            [
                'label' => esc_html__('Grid Columns Amount', 'corpix-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => esc_html__('1 / One', 'corpix-core'),
                    '2' => esc_html__('2 / Two', 'corpix-core'),
                    '3' => esc_html__('3 / Three', 'corpix-core'),
                    '4' => esc_html__('4 / Four', 'corpix-core'),
                    '5' => esc_html__('5 / Five', 'corpix-core'),
                    '6' => esc_html__('6 / Six', 'corpix-core'),
                ],
                'default' => '4',
            ]
        );

        $this->add_control(
			'add_hover_effect',
			[
				'label' => esc_html__( 'Add Hover Effect?', 'corpix-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'corpix-core' ),
				'label_off' => esc_html__( 'No', 'corpix-core' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->add_responsive_control(
            'hover_style',
            [
                'label' => esc_html__('Hover Style', 'corpix-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => esc_html__('Hover Style 01', 'corpix-core'),
                    '2' => esc_html__('Hover Style 02', 'corpix-core'),
                ],
                'default' => '1',
                'condition' => [
                    'add_hover_effect' => 'yes',
                ],
            ]
        );


        $repeater = new Repeater();

        $repeater->add_control(
            'thumbnail',
            [
                'label' => esc_html__('Thumbnail', 'corpix-core'),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
                'default' => [ 'url' => Utils::get_placeholder_image_src() ],
            ]
        );
        $repeater->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumb_size',
                'default' => 'large',
                'separator' => 'none',
            ]
        );

        $repeater->add_control(
            'list_title',
            [
                'label'   => __( 'Title', 'corpix-core' ),
                'type'    => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => __('Multi website launch','corpix-core'),

            ]    
        );
        $repeater->add_control(
            'list_text',
            [
                'label'   => __( 'Text', 'corpix-core' ),
                'type'    => Controls_Manager::TEXTAREA,
                'default' => __('Web Design','corpix-core'),
                'rows' => 1
            ]
        );

    
        $repeater->add_control(
            'link',
            [
                'label' => __( 'Link', 'corpix-core' ),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'corpix-core' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                ],
            ]
        );



        $this->add_control(
            'list',
            [
                'label' => esc_html__('Items', 'corpix-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                    'default' => [

                        [
                            'list_title'           => __('Multi website launch','corpix-core'),
                            'list_text'           => __('Web Design','corpix-core'),
                            'link'           => '#',
                        ],

                        [
                            'list_title'           => __('Multi website launch','corpix-core'),
                            'list_text'           => __('Web Design','corpix-core'),
                            'link'           => '#',
                        ],

                        [
                            'list_title'           => __('Multi website launch','corpix-core'),
                            'list_text'           => __('Web Design','corpix-core'),
                            'link'           => '#',
                        ],
                    ],
                    'title_field' => '{{{ list_title }}}',
            ]
        );

        $this->add_control(
            'show_read_more',
            [
                'label' => __( 'Icon Link', 'corpix-core' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'your-plugin' ),
                'label_off' => __( 'Hide', 'your-plugin' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();


       
        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> CAROUSEL OPTIONS
        /*-----------------------------------------------------------------------------------*/
            $this->start_controls_section(
                'tpc_carousel_section',
                ['label' => esc_html__('Carousel Options', 'corpix-core')]
            );

            $this->add_control(
                'autoplay',
                [
                    'label' => esc_html__('Autoplay', 'corpix-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__('On', 'corpix-core'),
                    'label_off' => esc_html__('Off', 'corpix-core'),
                ]
            );

            $this->add_control(
                'autoplay_speed',
                [
                    'label' => esc_html__('Autoplay Speed', 'corpix-core'),
                    'type' => Controls_Manager::NUMBER,
                    'min' => 1,
                    'step' => 1,
                    'default' => '5000',
                    'condition' => [
                        'autoplay' => 'yes',
                    ],
                ]
            );
            $this->add_control(
                'infinite',
                [
                    'label' => esc_html__('Infinite Loop Sliding', 'corpix-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__('On', 'corpix-core'),
                    'label_off' => esc_html__('Off', 'corpix-core'),
                    'return_value' => 'yes',
                    'default' => 'yes'
                ]
            );
            $this->add_control(
                'centeredmode',
                [
                    'label' => esc_html__('Centered Slides', 'corpix-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__('On', 'corpix-core'),
                    'label_off' => esc_html__('Off', 'corpix-core'),
                    'return_value' => 'yes',
                    'default' => 'yes'
                ]
            );
            $this->add_control(
                'coverflow_effect',
                [
                    'label' => esc_html__('Coverflow Effect', 'corpix-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__('On', 'corpix-core'),
                    'label_off' => esc_html__('Off', 'corpix-core'),
                ]
            );

              
            $this->add_responsive_control(
                'space_between',
                [
                    'label' => esc_html__('Space Between', 'corpix-core'),
                    'type' => Controls_Manager::NUMBER,
                    'default' => '20',
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'use_prev_next',
                [
                    'label' => esc_html__('Add Prev/Next buttons', 'corpix-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__('On', 'corpix-core'),
                    'label_off' => esc_html__('Off', 'corpix-core'),
                    'separator' => 'before',
                    'return_value' => 'yes',
                    'default' => 'yes',
                ]
            );
         
            $this->add_control(
                'use_pagination',
                [
                    'label' => esc_html__('Add Pagination', 'corpix-core'),
                    'type' => Controls_Manager::SWITCHER,
                    'label_on' => esc_html__('On', 'corpix-core'),
                    'label_off' => esc_html__('Off', 'corpix-core'),
                    'separator' => 'before',
                    'return_value' => 'yes',
                    'default' => '',
                    ]
            );
          $this->add_control(
                'pag_type',
                [
                    'label' => esc_html__('Pagination Type', 'corpix-core'),
                    'type' => 'tpc-radio-image',
                    'condition' => [
                        'use_pagination' => 'yes',
                    ],
                    'options' => [
                        'circle' => [
                            'title' => esc_html__('Circle', 'corpix-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_circle.png',
                        ],
                        'circle_border' => [
                            'title' => esc_html__('Empty Circle', 'corpix-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_circle_border.png',
                        ],
                        'square' => [
                            'title' => esc_html__('Square', 'corpix-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_square.png',
                        ],
                        'square_border' => [
                            'title' => esc_html__('Empty Square', 'corpix-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_square_border.png',
                        ],
                        'line' => [
                            'title' => esc_html__('Line', 'corpix-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_line.png',
                        ],
                        'line_circle' => [
                            'title' => esc_html__('Line - Circle', 'corpix-core'),
                            'image' => TPC_ELEMENTOR_ADDONS_URL . 'assets/img/tpc_elementor_addon/icons/pag_line_circle.png',
                        ],
                    ],
                    'default' => 'circle',
                ]
            );
            $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  STYLES -> IMAGES
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_images',
            [
                'label' => esc_html__('Style', 'corpix-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );



        $this->add_responsive_control(
			'image_size',
			[
				'label' => esc_html__( 'Height', 'elementor' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'unit' => 'px',
				],
				'tablet_default' => [
					'unit' => 'px',
				],
				'mobile_default' => [
					'unit' => 'px',
				],
				'size_units' => [ 'px', 'vh' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 1000,
					],
					'vh' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-link img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

        

        // $this->add_responsive_control(
        //     'project_content_padding',
        //     [
        //         'label' => __( 'Padding', 'corpix-core' ),
        //         'type' => Controls_Manager::DIMENSIONS,
        //         'size_units' => [ 'px', '%', 'em' ],
        //         'selectors' => [
        //             '{{WRAPPER}} .tpc-work-item .tpc-work-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
        //         ],
        //     ]
        // );
       
        $this->end_controls_section();



        $this->start_controls_section(
            'project_content_position',
            [
                'label' => esc_html__('Content Position', 'corpix-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );


        $this->add_responsive_control(
            'content_bottom_space',
            [
                'label' => esc_html__( 'Position-Y', 'elementor' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-content' => 'bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_left_space',
            [
                'label' => esc_html__( 'Position-X', 'elementor' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-content' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

    // Project Title Style start

    $this->start_controls_section(
        'project_title',
        [
            'label'     => __( 'Title', 'corpix-core' ),
            'tab'       => Controls_Manager::TAB_STYLE,
        ]
    );

    $this->add_control(
        'project_title_color',
        [
            'label' => __( 'Color', 'corpix-core' ),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-content .title' => 'color: {{VALUE}};',
            ],
        ]
    );

    $this->add_control(
        'title_bg_color',
        [
            'label' => __( 'Title Background Color', 'corpix-core' ),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-content .title' => 'background-color: {{VALUE}};',
            ],
        ]
    );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'project_title_typography',
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
                ],
                'selector' => '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-content .title',
            ]
        );

        $this->add_responsive_control(
            'title_bottom_space',
            [
                'label' => esc_html__( 'Spacing', 'elementor' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-content .title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );


    $this->end_controls_section(); // Project Title Style end

    // Project subtitle Style start
    $this->start_controls_section(
        'project_subtitle_style',
        [
            'label'     => __( 'Sub Title', 'corpix-core' ),
            'tab'       => Controls_Manager::TAB_STYLE,
        ]
    );
        
        $this->add_control(
            'project_subtitle_color',
            [
                'label' => __( 'Color', 'corpix-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-content .sub-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'subtitle_bg_color',
            [
                'label' => __( 'Subtitle Background Color', 'corpix-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-content .sub-title' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'project_subtitle_typography',
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_TEXT,
                ],
                'selector' => '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-content .sub-title', 
            ]
        );

        $this->add_responsive_control(
            'subtitle_bottom_space',
            [
                'label' => esc_html__( 'Spacing', 'elementor' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-content .sub-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );


    $this->end_controls_section(); // Project subtitle style end




    // Project Shape 1 Position Style start
    $this->start_controls_section(
        'project_shape1_style',
        [
            'label'     => __( 'Project Shape-1 Position', 'corpix-core' ),
            'tab'       => Controls_Manager::TAB_STYLE,
        ]
    );
      
    $this->add_control(
        'shape_1_position_y)',
        [
            'label' => esc_html__( 'Position-Y', 'corpix-core' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-link::before' => 'bottom: {{SIZE}}{{UNIT}};',
                ],
        ]
    );

    $this->add_control(
        'shape_1_position_x)',
        [
            'label' => esc_html__( 'Position-X', 'corpix-core' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-link::before' => 'right: {{SIZE}}{{UNIT}};',
                ],
        ]
    );
    

    $this->end_controls_section(); // Project Shape 1 Position style end


     // Project Shape 2 Position Style start
     $this->start_controls_section(
        'project_shape2_style',
        [
            'label'     => __( 'Project Shape-2 Position', 'corpix-core' ),
            'tab'       => Controls_Manager::TAB_STYLE,
        ]
    );
      
    $this->add_control(
        'shape_2_position_y)',
        [
            'label' => esc_html__( 'Position-Y', 'corpix-core' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-link::after' => 'bottom: {{SIZE}}{{UNIT}};',
                ],
        ]
    );

    $this->add_control(
        'shape_2_position_x)',
        [
            'label' => esc_html__( 'Position-X', 'corpix-core' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-link::after' => 'right: {{SIZE}}{{UNIT}};',
                ],
        ]
    );
    

    $this->end_controls_section(); // Project Shape 2 Position style end




        // Style arrow style start
        $this->start_controls_section(
            'cat_carousel_arrow_style',
            [
                'label'     => __('Prev/Next buttons', 'corpix-core'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'use_prev_next' => 'yes',
                ],
            ]
        );
        $this->add_control(
            'cat_carousel_arrow_color',
            [
                'label'     => __('Color', 'corpix-core'),
                'type'      => Controls_Manager::COLOR,
                'default'   => '#5A5A5A',
                'selectors' => [
                    '{{WRAPPER}} .corpix__carousel .swiper-button-next:after, .corpix__carousel .swiper-button-prev:after' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'cat_carousel_arrow_fontsize',
            [
                'label'      => __('Arrow Size', 'corpix-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 50,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .corpix__carousel .swiper-button-next:after, .corpix__carousel .swiper-button-prev:after' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_control(
            'arrow_bg_color',
            [
                'label'     => __('Background Color', 'corpix-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .corpix__carousel .swiper-button-next, .corpix__carousel .swiper-button-prev' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name'     => 'cat_carousel_arrow_border',
                'label'    => __('Border', 'corpix-core'),
                'selector' => '{{WRAPPER}} .corpix__carousel .swiper-button-next, .corpix__carousel .swiper-button-prev',
            ]
        );

        $this->add_responsive_control(
            'cat_carousel_arrow_border_radius',
            [
                'label'     => __('Border Radius', 'corpix-core'),
                'type'      => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .corpix__carousel .swiper-button-next, .corpix__carousel .swiper-button-prev' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
            ]
        );
        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'arrow_box_shadow',
                'selector' => '{{WRAPPER}} .corpix__carousel .swiper-button-next, .corpix__carousel .swiper-button-prev',
            ]
        );


        $this->end_controls_section(); // Style cat box arrow style end

        // Project Dots style start
        $this->start_controls_section(
            'cat_carousel_dots_style',
            [
                'label'     => __('Pagination', 'corpix-core'),
                'tab'       => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'use_pagination' => 'yes',
                ],
            ]
        );

        $this->start_controls_tabs('cat_carousel_dots_style_tabs');

        // Normal tab Start
        $this->start_controls_tab(
            'cat_carousel_dots_style_normal_tab',
            [
                'label' => __('Normal', 'corpix-core'),
            ]
        );

        $this->add_control(
            'dot_color',
            [
                'label'     => __('Color', 'corpix-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .corpix__carousel .swiper-pagination .swiper-pagination-bullet' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .corpix__carousel.pagination_square_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet:before' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .corpix__carousel.pagination_circle_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet:before' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'cat_carousel_dots_height',
            [
                'label'      => __('Size', 'corpix-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 30,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .corpix__carousel .swiper-pagination .swiper-pagination-bullet' => 'height: {{SIZE}}{{UNIT}}; width: {{SIZE}}{{UNIT}};',
                ],
                'condition' => [
                    'pag_type' => 'circle',
                ],
            ]
        );

        $this->add_responsive_control(
            'cat_carousel_dots_space',
            [
                'label'      => __('Space Between', 'corpix-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => 0,
                        'max'  => 30,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .corpix__carousel .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet' => 'margin-left: {{SIZE}}{{UNIT}}; margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'project_carousel_dots_margin_top',
            [
                'label'      => __('Margin Top', 'corpix-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => -300,
                        'max'  => 300,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => 45,
                ],
                'selectors'  => [
                    '{{WRAPPER}} .corpix__carousel .swiper-pagination' => 'margin-top: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'project_carousel_dots_position_y',
            [
                'label'      => __('Position Y', 'corpix-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => -300,
                        'max'  => 300,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .corpix__carousel .swiper-pagination' => 'bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'project_carousel_dots_position_x',
            [
                'label'      => __('Position X', 'corpix-core'),
                'type'       => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range'      => [
                    'px' => [
                        'min'  => -700,
                        'max'  => 700,
                        'step' => 1,
                    ],
                ],
                'default'    => [
                    'unit' => 'px',
                    'size' => '',
                ],
                'selectors'  => [
                    '{{WRAPPER}} .corpix__carousel .swiper-pagination' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_tab(); // Normal tab end

        // Hover tab Start
        $this->start_controls_tab(
            'cat_carousel_dots_style_hover_tab',
            [
                'label' => __('Active', 'corpix-core'),
            ]
        );
        $this->add_control(
            'dot_hover_color',
            [
                'label'     => __('Active Color', 'corpix-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .corpix__carousel .swiper-pagination .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .corpix__carousel.pagination_square_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet.swiper-pagination-bullet-active:before' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .corpix__carousel.pagination_square_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'border-color: {{VALUE}};',
                    '{{WRAPPER}} .corpix__carousel.pagination_circle_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet.swiper-pagination-bullet-active:before' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .corpix__carousel.pagination_circle_border .swiper-container-horizontal>.swiper-pagination-bullets .swiper-pagination-bullet.swiper-pagination-bullet-active' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab(); // Hover tab end

        $this->end_controls_tabs();

        $this->end_controls_section(); // Style cat box dots style end

    }

    protected function render()
    {
        $id = $this->get_id();
        $settings = $this->get_settings_for_display();
?>



<div class="corpix__carousel pagination_<?php echo esc_attr($settings['pag_type']) ?>">  



    <?php if ($settings['hover_style'] == '1'): ?>

        <div class="lmsmaer_service_id<?php echo $id; ?>">
                <div class="swiper-wrapper">

                <?php      
                    foreach ($settings['list'] as $index => $item) {


                ?>
        
                        <div class="swiper-slide">

                            <div class="tpc-work-item hover-<?php echo(esc_attr($settings['hover_style']))?>">
                                <div class="tpc-work-wrapper">
                                    
                                    <?php if($item['link']['url']): // a tag start ?>
                                        <a class="tpc-work-link"<?php if($item['link']['nofollow'] == 'on'): echo 'rel ="nofollow"'; endif;?> <?php if($item['link']['is_external'] == 'on'): echo 'target="_blank"'; endif; ?> href="<?php echo $item['link']['url'] ?>">
                                    <?php endif ?>

                                            <img src="<?php echo esc_url($item['thumbnail']['url'])?>" alt="">

                                    <?php if($item['link']['url']): ?>
                                        </a>
                                    <?php endif; // a tag end?>

                                    <div class="tpc-work-content">
                                        <div class="title-wrap">
                                            <h3 class="title"><?php echo $item['list_title']; ?></h3>
                                        </div>
                                        <div class="subtitle-warp">
                                            <h4 class="sub-title"><?php echo $item['list_text']; ?></h4>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>

                    <?php

                    } ?>
                </div>



                <!-- If we need navigation buttons -->
                <?php if ($settings['use_prev_next']): ?>
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-button-next"></div>
                <?php endif ?>
            <?php if ($settings['use_pagination']): ?>
                    <div class="swiper-pagination"></div>
                <?php endif ?>
            </div>
        </div> 

    <?php endif ?>

    <!-- For Hover Style 2 -->
    <?php if ($settings['hover_style'] == '2'): ?>

    <div class="lmsmaer_service_id<?php echo $id; ?>">
        <div class="swiper-wrapper">

        <?php      
            foreach ($settings['list'] as $index => $item) {


        ?>

                <div class="swiper-slide">

                    <div class="tpc-work-item hover-<?php echo(esc_attr($settings['hover_style']))?>">
                        <div class="tpc-work-wrapper">
                        <div class="shape-1"></div>
                            
                            <?php if($item['link']['url']): // a tag start ?>
                                <a class="tpc-work-link"<?php if($item['link']['nofollow'] == 'on'): echo 'rel ="nofollow"'; endif;?> <?php if($item['link']['is_external'] == 'on'): echo 'target="_blank"'; endif; ?> href="<?php echo $item['link']['url'] ?>">
                            <?php endif ?>

                                    <img src="<?php echo esc_url($item['thumbnail']['url'])?>" alt="">

                            <?php if($item['link']['url']): ?>
                                </a>
                            <?php endif; // a tag end?>

                            <div class="tpc-work-content">
                                <div class="title-wrap">
                                    <h3 class="title"><?php echo $item['list_title']; ?></h3>
                                </div>
                                <div class="subtitle-warp">
                                    <h4 class="sub-title"><?php echo $item['list_text']; ?></h4>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            <?php

            } ?>
        </div>



        <!-- If we need navigation buttons -->
        <?php if ($settings['use_prev_next']): ?>
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
        <?php endif ?>
    <?php if ($settings['use_pagination']): ?>
            <div class="swiper-pagination"></div>
        <?php endif ?>
    </div>
</div> 

<?php endif ?>


<script>
jQuery(document).ready(function() {
    new Swiper('.lmsmaer_service_id<?php echo $id; ?>', {
        <?php if ($settings['infinite']): ?>
            loop: true,
        <?php endif ?>        
        <?php if ($settings['centeredmode']): ?>
           centeredSlides: true,
        <?php endif ?>
        slidesPerView: 4,
        spaceBetween: 30,
        grabCursor: true, 
        <?php if ($settings['autoplay']): ?>
          autoplay: {
            delay: <?php echo esc_attr($settings['autoplay_speed']); ?>,
          },
        <?php endif ?>
          pagination: {
            el: ".swiper-pagination",
            clickable: true,
          },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev"
        },

        breakpoints: {
            0: {
                slidesPerView: <?php echo $settings['item_grid'] ?>,
            },

            767: {
                slidesPerView: <?php echo $settings['item_grid'] ?>,
                spaceBetween: <?php echo $settings['space_between'] ?>
            },

            1024: {
                slidesPerView: <?php echo $settings['item_grid'] ?>,
                spaceBetween: <?php echo $settings['space_between'] ?>
            },

            1200: {
                slidesPerView: <?php echo $settings['item_grid'] ?>,
            },

        }
    });
});
</script>
<?php

    }

}




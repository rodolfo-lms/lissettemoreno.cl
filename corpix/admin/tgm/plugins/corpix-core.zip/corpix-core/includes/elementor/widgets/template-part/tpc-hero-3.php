<?php 
$settings = $this->get_settings_for_display();?>


<div class="corpix-hero-section-03 <?php echo esc_attr($hide_animated_shape)?>">
	<div class="hero-img-3">
		<img src="<?php echo esc_url($settings['hero_image']['url'])?>" alt="">
	</div>
	<div class="shape-1">
		<img src="<?php echo esc_url($settings['image_shape_1']['url'])?>" alt="">
	</div>
	<div class="shape-2">
		<img src="<?php echo esc_url($settings['image_shape_2']['url'])?>" alt="">
	</div>
	<div class="shape-3"></div>
	<div class="corpix-container">
		<div class="row">
			<div class="col-lg-8">
				<!-- Hero Content Start -->
				<div class="hero-content">
					<?php if($settings['sub_title']) : ?>
						<h3 class="sub-title" data-aos-delay="600" data-aos="fade-up"><?php echo $settings['sub_title']; ?></h3>
					<?php endif;?> 
					<h2 class="title" data-aos="fade-up" data-aos-delay="700">
						<span class="title-1">
							<?php echo ($settings['title_1'])?($settings['title_1']):('')?>
						</span>
						<span class="title-1">
							<?php echo ($settings['title_2'])?($settings['title_2']):('')?>
						</span>
						<span class="title-2"><?php echo ($settings['title_3'])?($settings['title_3']):('')?></span>
					</h2>
				</div>
				<!-- Hero Content End -->
			</div>
		</div>
	</div>
</div>


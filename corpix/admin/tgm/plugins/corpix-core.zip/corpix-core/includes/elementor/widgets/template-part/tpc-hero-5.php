<?php $settings = $this->get_settings_for_display();?>

<div class="corpix-hero-section-05 d-flex align-items-center">
	<div class="hero-bg" style="background-image: url(<?php echo esc_url($settings['hero_wrapper_bg']['url'])?>)"></div>
	<div class="shape-1">
		<svg xmlns="http://www.w3.org/2000/svg" width="717px" height="1251px">
			<path d="M420.321,4.713 L609.33,54.235 C685.667,74.345 731.498,152.808 711.399,229.485 L471.937,1143.35 C451.838,1219.713 373.420,1265.570 296.785,1245.459 L108.73,1195.938 C31.439,1175.827 -14.391,1097.365 5.707,1020.687 L245.170,107.137 C265.269,30.460 343.686,-15.397 420.321,4.713 Z"></path>
		</svg>
	</div>
	<div class="shape-2">
		<svg xmlns="http://www.w3.org/2000/svg" width="718.5px" height="1253.5px">
			<path d="M420.713,6.40 L609.425,55.561 C686.60,75.672 731.891,154.134 711.792,230.812 L472.329,1144.361 C452.230,1221.39 373.812,1266.896 297.178,1246.786 L108.466,1197.265 C31.832,1177.154 -13.999,1098.691 6.100,1022.14 L245.562,108.464 C265.661,31.786 344.79,-14.70 420.713,6.40 Z"></path>
		</svg>
	</div>
	<div class="shape-3">
		<svg xmlns="http://www.w3.org/2000/svg" width="500px" height="872px">
			<path d="M293.58,3.783 L424.608,38.284 C478.30,52.295 509.979,106.961 495.968,160.382 L329.39,796.856 C315.28,850.278 260.363,882.226 206.941,868.215 L75.391,833.713 C21.969,819.702 -9.979,765.38 4.31,711.616 L170.960,75.142 C184.971,21.720 239.636,-10.227 293.58,3.783 Z"></path>
		</svg>
	</div>
	<div class="shape-4">
		<svg xmlns="http://www.w3.org/2000/svg" width="501.5px" height="873.5px">
			<path d="M293.558,4.283 L425.108,38.785 C478.530,52.795 510.479,107.461 496.468,160.882 L329.539,797.356 C315.528,850.778 260.863,882.726 207.441,868.716 L75.891,834.213 C22.469,820.202 -9.479,765.538 4.531,712.116 L171.460,75.642 C185.471,22.221 240.136,-9.727 293.558,4.283 Z"></path>
		</svg>
	</div>
	<div class="corpix-container">
		<div class="row align-items-center">
			<div class="col-xl-7 col-lg-7">
				<!-- Hero Content Start -->
				<div class="hero-content">
                    <?php if($settings['sub_title']) : ?>
                        <h3 class="sub-title" data-aos-delay="600" data-aos="fade-up">
                            <?php echo $settings['sub_title']; ?>
                        </h3>
                    <?php endif;?> 
					<?php if($settings['title']) : ?>
                        <h2 class="title" data-aos="fade-up" data-aos-delay="700">
                            <?php echo $settings['title']; ?>
                        </h2>
                    <?php endif;?>
					<?php if($settings['show_btn']) : ?>
                        <div class="corpix-hero-btn" data-aos="fade-up" data-aos-delay="900">
                            <?php if($settings['btn_link']['url']):?>
                                <a class="corpix-btn" <?php if($settings['btn_link']['nofollow'] == 'on'): echo 'rel ="nofollow"'; endif;?> <?php if($settings['btn_link']['is_external'] == 'on'): echo 'target="_blank"'; endif; ?> href="<?php echo $settings['btn_link']['url'] ?>">
                            <?php endif ?>
                                <?php echo $settings['btn_text']; ?> 

                            <?php if($settings['btn_link']['url']): ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
				</div>
			</div>
			<!-- Hero Content End -->
		</div>
	</div>
</div>

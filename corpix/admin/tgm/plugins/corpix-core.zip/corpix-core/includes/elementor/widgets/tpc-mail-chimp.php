<?php
/*
 * This template can be overridden by copying it to yourtheme/corpix-core/elementor/widgets/tpc-team.php.
 */
namespace TPCAddons\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.

use Elementor\Controls_Manager;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;

class TPC_Mail_Chimp extends Widget_Base
{
    public function get_name()
    {
        return 'tpc-mail-chimp';
    }

    public function get_title()
    {
        return esc_html__('Mailchimp', 'corpix-core');
    }
    public function get_keywords()
    {
        return ['mailchimp','subscribe','subscriber', 'mail', 'marketing', 'contact', 'mail chimp', 'form', 'email'];
    }
    public function get_icon()
    {
        return 'tpc-icon eicon-mailchimp';
    }

    public function get_categories()
    {
        return ['tpc-extensions'];
    }
    public function tpc_mail_chimp_form()
    {
        $countactform      = array();
        $tpc_forms_args = array('posts_per_page' => -1, 'post_type' => 'mc4wp-form');
        $htmega_forms      = get_posts($tpc_forms_args);
        if ($htmega_forms) {
            foreach ($htmega_forms as $htmega_form) {
                $countactform[$htmega_form->ID] = $htmega_form->post_title;
            }
        } else {
            $countactform[esc_html__('Mailchimp form not selected', 'corpix-core')] = 0;
        }
        return $countactform;
    }

    protected function register_controls() {

        $this->start_controls_section(
            'section_content',
            [
                'label' => __( 'Content', 'corpix-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'tpc_mail_chimp_form_list',
            [
                'label'   => __('Search Form', 'corpix-core'),
                'type'    => \Elementor\Controls_Manager::SELECT,
                'options' => $this->tpc_mail_chimp_form(),
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'section_style',
            [
                'label' => __( 'Style', 'corpix-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        // $this->add_responsive_control(
        //     'description_align',
        //     [
        //         'label'     => __('Alignment', 'corpix-core'),
        //         'type'      => Controls_Manager::CHOOSE,
        //         'options'   => [
        //             'left'  => [
        //                 'title' => __('Left', 'corpix-core'),
        //                 'icon'  => 'fa fa-align-left',
        //             ],
        //             'center'  => [
        //                 'title' => __('Center', 'corpix-core'),
        //                 'icon'  => 'fa fa-align-center',
        //             ],
        //             'right' => [
        //                 'title' => __('Right', 'corpix-core'),
        //                 'icon'  => 'fa fa-align-right',
        //             ],
        //         ],
        //         'selectors' => [
        //             '{{WRAPPER}} .tpc-mailchimp-form-wrap' => 'text-align: {{VALUE}};',
        //         ],
        //         'default'   => 'center',
        //     ]
        // );
        $this->add_responsive_control(
            'froms_width',
            [
                'label'  => __( 'Width', 'corpix-core' ),
                'type'   => Controls_Manager::SLIDER,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [
                        'min' => 150,
                        'max' => 1000,
                        'step' => 1,
                    ],
                    '%' => [
                        'min' => 1,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-mailchimp-form-wrap input[type=email]' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );        
        $this->add_responsive_control(
            'froms_height',
            [
                'label'  => __( 'Height', 'corpix-core' ),
                'type'   => Controls_Manager::SLIDER,
                'range'  => [
                    'px' => [
                        'min' => 42,
                        'max' => 120,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-mailchimp-form-wrap input[type=email], .tpc-mailchimp-form-wrap .btn' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'froms_submit_width',
            [
                'label'  => __( 'Submit Button Width', 'corpix-core' ),
                'type'   => Controls_Manager::SLIDER,
                'range'  => [
                    'px' => [
                        'min' => 10,
                        'max' => 300,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-mailchimp-form-wrap .btn' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

       $this->add_responsive_control(
            'froms_input_border_radious',
            [
                'label' => esc_html__( 'Input Border Radius', 'corpix-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .tpc-mailchimp-form-wrap input' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
            ]
        );
        $this->add_responsive_control(
            'froms_button_border_radious',
            [
                'label'     => esc_html__('Button Border Radius', 'corpix-core'),
                'type'      => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .tpc-mailchimp-form-wrap .btn' => 'border-radius: {{TOP}}px {{RIGHT}}px {{BOTTOM}}px {{LEFT}}px;',
                ],
            ]
        );
        $this->add_control(
            'input_color',
            [
                'label'     => __( 'Input Text', 'corpix-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tpc-mailchimp-form-wrap input' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'input_border_color',
            [
                'label'     => __( 'Input Border', 'corpix-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tpc-mailchimp-form-wrap input' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'input_bg_color',
            [
                'label'     => __( 'Input Background', 'corpix-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tpc-mailchimp-form-wrap input' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'btn_bg_color',
            [
                'label'     => __( 'Submit Background', 'corpix-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tpc-mailchimp-form-wrap .btn' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'btn_bg_hover_color',
            [
                'label'     => __( 'Submit Background Hover', 'corpix-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tpc-mailchimp-form-wrap .btn:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'btn_border_color',
            [
                'label'     => __( 'Submit Border', 'corpix-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tpc-mailchimp-form-wrap .btn' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'submit_typography',
                'label'    => __( 'Submit Typography', 'corpix-core' ),
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_ACCENT,
                ],
                'selector' => '{{WRAPPER}} .tpc-mailchimp-form-wrap .btn',
            ]
        );
        
        $this->add_control(
            'input_placholder_color',
            [
                'label'     => __( 'Placeholder', 'corpix-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tpc-mailchimp-form-wrap input::placeholder' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'btn_text_color',
            [
                'label'     => __( 'Submit Text', 'corpix-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tpc-mailchimp-form-wrap .btn' => 'color: {{VALUE}};',

                ],
            ]
        );

        $this->add_control(
            'btn_text_hover_color',
            [
                'label'     => __( 'Submit Text Hover', 'corpix-core' ),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tpc-mailchimp-form-wrap .btn:hover' => 'color: {{VALUE}};',

                ],
            ]
        );
        $this->end_controls_section();

    } // End options

    protected function render( $instance = [] ) {
        
        $settings = $this->get_settings();
        ?>

            <?php
                if (!empty($settings['tpc_mail_chimp_form_list'])) {
                    echo do_shortcode('[mc4wp_form  id="' . $settings['tpc_mail_chimp_form_list'] . '"]');
                } else {
                    echo '<div class="form_no_select">' . __('Mailchimp form not selected', 'corpix-core') . '</div>';
                }
            ?>

        <?php

    }

}


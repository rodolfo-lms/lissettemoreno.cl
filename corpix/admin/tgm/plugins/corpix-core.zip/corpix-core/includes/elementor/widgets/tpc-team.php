<?php
/*
 * This template can be overridden by copying it to yourtheme/corpix-core/elementor/widgets/tpc-team.php.
 */
namespace TPCAddons\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use Elementor\Repeater;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;

use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

class TPC_Team extends Widget_Base
{
    public function get_name()
    {
        return 'tpc-team';
    }

    public function get_title()
    {
        return esc_html__('Team', 'corpix-core');
    }

    public function get_icon()
    {
        return 'tpc-icon eicon-person';
    }

    public function get_categories()
    {
        return ['tpc-extensions'];
    }

    protected function register_controls()
    {

        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Team Content', 'corpix-core'),
            ]
        );
        $this->add_control(
            'grid_columns',
            [
                'label'   => __('Items Column', 'corpix-core'),
                'type'    => Controls_Manager::SELECT,
                'default' => '3',
                'options' => [
                    '12' => __('1 Column', 'corpix-core'),
                    '6'  => __('2 Column', 'corpix-core'),
                    '4'  => __('3 Column', 'corpix-core'),
                    '3'  => __('4 Column', 'corpix-core'),
                    '2'  => __('6 Column', 'corpix-core'),
                ],
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'teacher_image',
            [
                'label'   => esc_html__('Team Image', 'corpix-core'),
                'type'    => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );
        $repeater->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name'      => 'teacher_imagesize',
                'default'   => 'medium',
                'separator' => 'none',
            ]
        );
        $repeater->add_control(
            'teacher_name',
            [
                'label'       => esc_html__('Name', 'corpix-core'),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => esc_html__('Jonathan Bean', 'corpix-core'),
            ]
        );

        $repeater->add_control(
            'teacher_degree',
            [
                'label'       => esc_html__('Designation', 'corpix-core'),
                'type'        => Controls_Manager::TEXT,
                'label_block' => true,
                'default'     => esc_html__('Math Team', 'corpix-core'),
            ]
        );

        $repeater->add_control(
            'teacher_details_link',
            [
                'label' => __('Team details page link', 'corpix-core'),
                'type'  => Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                ],
            ]
        );

        $repeater->add_control(
            'fb_link',
            [
                'label'     => __('Facebook', 'corpix-core'),
                'type'      => Controls_Manager::URL,
            ]
        );

        $repeater->add_control(
            'twitter_link',
            [
                'label'     => __('Twitter', 'corpix-core'),
                'type'      => Controls_Manager::URL,

            ]
        );

        $repeater->add_control(
            'youtube_link',
            [
                'label'     => __('Youtube', 'corpix-core'),
                'type'      => Controls_Manager::URL,
            ]
        );

        $repeater->add_control(
            'linkedin_link',
            [
                'label'     => __('Linkedin', 'corpix-core'),
                'type'      => Controls_Manager::URL,
            ]
        );

        $repeater->add_control(
            'instagram_link',
            [
                'label'     => __('Instagram', 'corpix-core'),
                'type'      => Controls_Manager::URL,
            ]
        );

        $repeater->add_control(
            'skype_link',
            [
                'label'     => __('Skype', 'corpix-core'),
                'type'      => Controls_Manager::URL,
            ]
        );

        $repeater->add_control(
            'whatsapp_link',
            [
                'label'     => __('Whatsapp', 'corpix-core'),
                'type'      => Controls_Manager::URL,

            ]
        );
        $repeater->add_control(
            'snapchat_link',
            [
                'label'     => __('Snapchat', 'corpix-core'),
                'type'      => Controls_Manager::URL,
            ]
        );
        $repeater->add_control(
            'github_link',
            [
                'label'     => __('Github', 'corpix-core'),
                'type'      => Controls_Manager::URL,
            ]
        );
        $repeater->add_control(
            'gitlab_link',
            [
                'label'     => __('Gitlab', 'corpix-core'),
                'type'      => Controls_Manager::URL,
            ]
        );

        $this->add_control(
            'teacher_options',
            [
                'label'       => esc_html__('Add Team', 'corpix-core'),
                'type'        => Controls_Manager::REPEATER,
                'show_label'  => true,
                'default'     => [
                    [
                        'teacher_image'  => '',
                        'teacher_name'   => esc_html__('Team 1', 'corpix-core'),
                        'teacher_degree' => esc_html__('Degree 1', 'corpix-core'),
                    ],
                    [
                        'teacher_image'  => '',
                        'teacher_name'   => esc_html__('Team 2', 'corpix-core'),
                        'teacher_degree' => esc_html__('Degree 2', 'corpix-core'),
                    ],
                    [
                        'teacher_image'  => '',
                        'teacher_name'   => esc_html__('Team 3', 'corpix-core'),
                        'teacher_degree' => esc_html__('Degree 3', 'corpix-core'),
                    ],
                    [
                        'teacher_image'  => '',
                        'teacher_name'   => esc_html__('Team 4', 'corpix-core'),
                        'teacher_degree' => esc_html__('Degree 4', 'corpix-core'),
                    ],
                ],
                'fields'  => $repeater->get_controls(),
                'title_field' => '{{{teacher_name}}}',
            ]
        );

        $this->add_control(
            'name_tag',
            [
                'label' => __( 'Name Tag', 'corpix-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                    'div' => 'div',
                    'span' => 'span',
                    'p' => 'p',
                ],
                'default' => 'h3',
            ]
        );

        $this->add_control(
            'degree_tag',
            [
                'label' => __( 'Degree Tag', 'corpix-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                    'div' => 'div',
                    'span' => 'span',
                    'p' => 'p',
                ],
                'default' => 'p',
            ]
        );

        $this->end_controls_section();

        /* ============ Style Section ============ */

        $this->start_controls_section(
            'section_styles',
            [
                'label' => esc_html__('Styles', 'corpix-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'image_fixed_height',
            [
                'label'     => __('Image Height', 'corpix-core'),
                'type'      => Controls_Manager::SLIDER,
                'range'     => [
                    'px' => [
                        'min' => 80,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .corpix-teacher-wrapper .teacher-image img' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'base_color_1',
            [
                'label'     => __('Base Color 1', 'corpix-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .corpix-teacher-wrapper .teacher-img a::before'     => 'background-color: {{VALUE}};',
                ],
            ]
        );
        $this->add_responsive_control(
            'base_color_2',
            [
                'label'     => __('Base Color 2', 'corpix-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .corpix-teacher-wrapper .teacher-img a::after'     => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'teacher_button_padding',
            [
                'label'      => __('Content Padding', 'corpix-core'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors'  => [
                    '{{WRAPPER}} .corpix-teacher-wrapper .teacher-bottom' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
            ]
        );

        $this->add_responsive_control(
            'teacher_margin',
            [
                'label'      => __('Margin', 'corpix-core'),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => ['px'],
                'selectors'  => [
                    '{{WRAPPER}} .corpix-teacher-wrapper ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'separator'  => 'before',
                'default' => [
                    'top' => 0,
                    'left' => 0,
                    'right' => 0,
                    'bottom' => 35,
                ],
            ]
        );
        $this->add_responsive_control(
            'teacher_button_bg_color',
            [
                'label'     => __('Button Background', 'corpix-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .corpix-teacher-wrapper .teacher-bottom' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'teacher_border_color',
            [
                'label'     => __('Border Color', 'corpix-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .corpix-teacher-wrapper:hover .teacher-bottom::before' => 'background: {{VALUE}};',
                    '{{WRAPPER}} .corpix-teacher-wrapper .teacher-bottom::before' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
        // Star style tab
        $this->start_controls_section(
            'teacher_name_style',
            [
                'label' => esc_html__('Name', 'corpix-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs('tabs_title_style');

        $this->start_controls_tab(
            'tab_title_normal',
            [
                'label' => __('Normal', 'corpix-core'),
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'     => __('Title Color', 'corpix-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .corpix-teacher-wrapper .teacher-name' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_title_hover',
            [
                'label' => __('Hover', 'corpix-core'),
            ]
        );

        $this->add_control(
            'title_hover_color',
            [
                'label'     => __('Title Hover Color', 'corpix-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .corpix-teacher-wrapper a:hover .teacher-name' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'name_typography',
                'selector' => '{{WRAPPER}} .corpix-teacher-wrapper .teacher-name',
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_ACCENT,
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'teacher_degree_style',
            [
                'label' => esc_html__('Degree', 'corpix-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'digree_color',
            [
                'label'     => __('Degree', 'corpix-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .corpix-teacher-wrapper .teacher-deg' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name'     => 'digree_typography',
                'selector' => '{{WRAPPER}} .corpix-teacher-wrapper .teacher-deg',
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_TEXT,
                ],
            ]
        );
        $this->end_controls_section();

        $this->start_controls_section(
            'teacher_social_style',
            [
                'label' => esc_html__('Social', 'corpix-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->add_control(
            'icon_color',
            [
                'label'     => __('Icon', 'corpix-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .corpix-teacher-wrapper .social-shear .team-icon' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_hover_color',
            [
                'label'     => __('Icon Hover', 'corpix-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .corpix-teacher-wrapper .social-shear a.team-icon' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->end_controls_section();
    }
    protected function render($instance = [])
    {
        $settings = $this->get_settings_for_display();

        $this->add_render_attribute('teacher_area_attr', 'class', 'corpix-teacher');
        $this->add_render_attribute('teacher_row', 'class', 'row');
        $this->add_render_attribute('corpix_grid_columns', 'class', 'corpix-clm col-sm-6 col-lg-' . $settings['grid_columns']);

        ?>
    <div class="corpix-teacher-layout layout-1">
        <div <?php echo $this->get_render_attribute_string('teacher_row'); ?> >

            <?php foreach ($settings['teacher_options'] as $teacher_option): ?>

                <div <?php echo $this->get_render_attribute_string('corpix_grid_columns'); ?> >

                    <div class="corpix-teacher-wrapper">
                        <div class="teacher-img">
                            
                                <a href="<?php echo $teacher_option['teacher_details_link']['url'] ?>">
                                    <?php
                                    echo '<div class="teacher-image">' . Group_Control_Image_Size::get_attachment_image_html($teacher_option, 'teacher_imagesize', 'teacher_image') . '</div>';
                                    ?>
                                 </a>
                           
                        </div>

                        <div class="teacher-bottom">
                                                       
                            <div class="social-shear">

                                <?php if ($teacher_option['fb_link']['url'] || $teacher_option['twitter_link']['url'] || $teacher_option['gitlab_link']['url'] || $teacher_option['github_link']['url'] || $teacher_option['linkedin_link']['url'] || $teacher_option['whatsapp_link']['url'] || $teacher_option['snapchat_link']['url'] || $teacher_option['skype_link']['url'] || $teacher_option['instagram_link']['url'] ): ?>
                                    <ul class="team-info-icons">
                                        <li>
                                            <?php if ($teacher_option['fb_link']['url']): ?>
                                                <a href="<?php echo esc_url($teacher_option['fb_link']['url']); ?>" <?php if ($teacher_option['fb_link']['is_external']): echo 'target="_blank"';endif;?> class="team-icon fab fa-facebook">
                                                </a>
                                            <?php endif;?>
                                        </li>

                                        <li>
                                            <?php if ($teacher_option['twitter_link']['url']): ?>
                                                <a href="<?php echo esc_url($teacher_option['twitter_link']['url']); ?>" <?php if ($teacher_option['twitter_link']['is_external']): echo 'target="_blank"';endif;?> class="team-icon fab fa-twitter">
                                                </a>
                                            <?php endif;?>
                                        </li>

                                        <li>
                                            <?php if ($teacher_option['youtube_link']['url']): ?>
                                                <a href="<?php echo esc_url($teacher_option['youtube_link']['url']); ?>" <?php if ($teacher_option['youtube_link']['is_external']): echo 'target="_blank"';endif;?> class="team-icon fab fa-youtube">
                                                </a>
                                            <?php endif;?>
                                        </li>

                                        <li>
                                            <?php if ($teacher_option['linkedin_link']['url']): ?>
                                                <a href="<?php echo esc_url($teacher_option['linkedin_link']['url']); ?>" <?php if ($teacher_option['linkedin_link']['is_external']): echo 'target="_blank"';endif;?> class="team-icon fab fa-linkedin">
                                                </a>
                                            <?php endif;?>
                                        </li>
  
                                        <li>
                                            <?php if ($teacher_option['instagram_link']['url']): ?>
                                                <a href="<?php echo esc_url($teacher_option['instagram_link']['url']); ?>" <?php if ($teacher_option['instagram_link']['is_external']): echo 'target="_blank"';endif;?> class="team-icon fab fa-instagram">
                                                </a>
                                            <?php endif;?>
                                        </li>

                                        <li>
                                            <?php if ($teacher_option['skype_link']['url']): ?>
                                                <a href="<?php echo esc_url($teacher_option['skype_link']['url']); ?>" <?php if ($teacher_option['skype_link']['is_external']): echo 'target="_blank"';endif;?> class="team-icon fab fa-skype">
                                                </a>
                                            <?php endif;?>
                                        </li>

                                        <li>
                                            <?php if ($teacher_option['whatsapp_link']['url']): ?>
                                                <a href="<?php echo esc_url($teacher_option['whatsapp_link']['url']); ?>" <?php if ($teacher_option['whatsapp_link']['is_external']): echo 'target="_blank"';endif;?> class="team-icon fab fa-whatsapp">
                                                </a>
                                            <?php endif?>
                                        </li>

                                        <li>
                                            <?php if ($teacher_option['snapchat_link']['url']): ?>
                                                <a href="<?php echo esc_url($teacher_option['snapchat_link']['url']); ?>" <?php if ($teacher_option['snapchat_link']['is_external']): echo 'target="_blank"';endif;?> class="team-icon fab fa-snapchat-ghost">
                                                </a>
                                            <?php endif;?>
                                        </li>

                                        <li>
                                            <?php if ($teacher_option['github_link']['url']): ?>
                                                <a href="<?php echo esc_url($teacher_option['github_link']['url']); ?>" <?php if ($teacher_option['github_link']['is_external']): echo 'target="_blank"';endif;?> class="team-icon fab fa-github">
                                                </a>
                                            <?php endif;?>
                                        </li>

                                        <li>
                                            <?php if ($teacher_option['gitlab_link']['url']): ?>
                                                <a href="<?php echo esc_url($teacher_option['gitlab_link']['url']); ?>" <?php if ($teacher_option['gitlab_link']['is_external']): echo 'target="_blank"';endif;?> class="team-icon fab fa-gitlab">
                                                </a>
                                            <?php endif;?>
                                        </li>
                                    </ul>
                                <?php endif;?>

                            </div>

                            <?php if ($teacher_option['teacher_details_link']['url']): ?>
                                <a href="<?php echo $teacher_option['teacher_details_link']['url'] ?>">
                            <?php endif;?>
                                <<?php echo esc_attr( $settings['name_tag'] ); ?> class="teacher-name"><?php echo $teacher_option['teacher_name']; ?></<?php echo esc_attr( $settings['name_tag'] ); ?>>
                            <?php if ($teacher_option['teacher_details_link']['url']): ?>
                                </a>
                            <?php endif;?>

                            <?php if ($teacher_option['teacher_degree']): ?>
                                <<?php echo esc_attr( $settings['degree_tag'] ); ?> class="teacher-deg"><?php echo $teacher_option['teacher_degree']; ?></<?php echo esc_attr( $settings['degree_tag'] ); ?>>
                            <?php endif;?>
                        </div>
                    </div>
                </div>

            <?php endforeach;?>

        </div>
    </div>
<?php
}
}

<?php $settings = $this->get_settings_for_display();?>

<div class="corpix-hero-section-06">
	<div class="corpix-container">
		<div class="row align-items-center">
			<div class="col-lg-9 col-12">
				<!-- Hero Content Start -->
				<div class="hero-content">
                    <?php if($settings['sub_title']) : ?>
                        <h3 class="sub-title" data-aos-delay="600" data-aos="fade-up">
                            <?php echo $settings['sub_title']; ?>
                        </h3>
                    <?php endif;?> 
					<?php if($settings['title']) : ?>
                        <h2 class="title" data-aos="fade-up" data-aos-delay="700">
                            <?php echo $settings['title']; ?>
                        </h2>
                    <?php endif;?>
					<?php if($settings['show_btn']) : ?>
                        <div class="corpix-hero-btn" data-aos="fade-up" data-aos-delay="900">
                            <?php if($settings['btn_link']['url']):?>
                                <a class="corpix-btn" <?php if($settings['btn_link']['nofollow'] == 'on'): echo 'rel ="nofollow"'; endif;?> <?php if($settings['btn_link']['is_external'] == 'on'): echo 'target="_blank"'; endif; ?> href="<?php echo $settings['btn_link']['url'] ?>">
                            <?php endif ?>
                                <?php echo $settings['btn_text']; ?> 

                            <?php if($settings['btn_link']['url']): ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
				</div>
				<!-- Hero Content End -->
			</div>
		</div>
	</div>
</div>
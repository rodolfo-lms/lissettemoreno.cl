(function ($) {
    "use strict";

      // Image hover parallaxed effect
        var b = document.getElementsByTagName("BODY")[0];  

        b.addEventListener("mousemove", function(event) {
          parallaxed(event);

        });

        function parallaxed(e) {
              var amountMovedX = (e.clientX * -0.2 / 9);
              var amountMovedY = (e.clientY * -0.2 / 9);
              var x = document.getElementsByClassName("parallaxed");
              var i;
              for (i = 0; i < x.length; i++) {
                x[i].style.transform='translate(' + amountMovedX + 'px,' + amountMovedY + 'px)'
              }
        }


    // Elementor/frontend/init

    jQuery(window).on('elementor/frontend/init', function () {
        if (window.elementorFrontend.isEditMode()) {
            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-blog.default',
                function ($scope) {
                    corpix_parallax_video();
                    corpix_blog_masonry_init();
                    corpix_carousel_slick();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-blog-hero.default',
                function ($scope) {
                    corpix_parallax_video();
                    corpix_blog_masonry_init();
                    corpix_carousel_slick();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-carousel.default',
                function ($scope) {
                    corpix_carousel_slick();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-portfolio.default',
                function ($scope) {
                    corpix_isotope();
                    corpix_carousel_slick();
                    corpix_scroll_animation();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-gallery.default',
                function ($scope) {
                    corpix_images_gallery();
                    corpix_carousel_slick();
                    corpix_scroll_animation();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-progress-bar.default',
                function ($scope) {
                    corpix_progress_bars_init();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-testimonials.default',
                function ($scope) {
                    corpix_carousel_slick();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-slider.default',
                function ($scope) {
                    corpix_carousel_slick();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-toggle-accordion.default',
                function ($scope) {
                    corpix_accordion_init();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-accordion-service.default',
                function ($scope) {
                    corpix_services_accordion_init();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-team.default',
                function ($scope) {
                    corpix_isotope();
                    corpix_carousel_slick();
                    corpix_scroll_animation();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-tabs.default',
                function ($scope) {
                    corpix_tabs_init();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-clients.default',
                function ($scope) {
                    corpix_carousel_slick();
                }
            );

            // window.elementorFrontend.hooks.addAction(
            //     'frontend/element_ready/tpc-testimonial.default',
            //     function ($scope) {
            //         corpix_carousel_swiper();
            //     }
            // );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-image-layers.default',
                function ($scope) {
                    corpix_img_layers();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-video-popup.default',
                function ($scope) {
                    corpix_videobox_init();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-countdown.default',
                function ($scope) {
                    corpix_countdown_init();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-time-line-vertical.default',
                function ($scope) {
                    corpix_init_timeline_appear();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-striped-services.default',
                function ($scope) {
                    corpix_striped_services_init();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-image-comparison.default',
                function ($scope) {
                    corpix_image_comparison();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-circuit-service.default',
                function ($scope) {
                    corpix_circuit_service();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-counter.default',
                function ($scope) {
                    corpix_counter_init();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-menu.default',
                function ($scope) {
                    corpix_menu_lavalamp();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-header-search.default',
                function ($scope) {
                    corpix_search_init();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-header-side_panel.default',
                function ($scope) {
                    corpix_side_panel_init();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-courses.default',
                function($scope) {
                    corpix_carousel_slick();
                    corpix_isotope();
                }
            );

            window.elementorFrontend.hooks.addAction(
                'frontend/element_ready/tpc-courses-alt.default',
                function($scope) {
                    corpix_carousel_slick();
                    corpix_isotope();
                }
            );

        }
    });

})(jQuery);

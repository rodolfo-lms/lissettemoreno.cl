<?php
/*
 * This template can be overridden by copying it to yourtheme/corpix-core/elementor/widgets/tpc-cat-item.php.
*/
namespace TPCAddons\Widgets;

defined('ABSPATH') || exit; // Abort, if called directly.

use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;



use Elementor\{Widget_Base, Controls_Manager, Control_Media, Group_Control_Image_Size, Group_Control_Background, Group_Control_Box_Shadow, Group_Control_Typography, Utils};

use TPCAddons\Corpix_Global_Variables as Corpix_Globals;

class TPC_Project_Single extends Widget_Base
{

    public function get_name()
    {
        return 'tpc-project';
    }

    public function get_title()
    {
        return esc_html__('Project Single', 'corpix-core');
    }

    public function get_icon()
    {
        return 'tpc-icon eicon-gallery-grid';
    }

    public function get_categories()
    {
        return ['tpc-extensions'];
    }

    protected function register_controls()
    {
        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> GENERAL
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_content_general',
            [ 'label' => esc_html__('General', 'corpix-core') ]
        );


        $this->add_control(
			'add_hover_effect',
			[
				'label' => esc_html__( 'Add Hover Effect?', 'corpix-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'corpix-core' ),
				'label_off' => esc_html__( 'No', 'corpix-core' ),
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

        $this->add_responsive_control(
            'hover_style',
            [
                'label' => esc_html__('Hover Style', 'corpix-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => esc_html__('Hover Style 01', 'corpix-core'),
                    '2' => esc_html__('Hover Style 02', 'corpix-core'),
                ],
                'default' => '1',
                'condition' => [
                    'add_hover_effect' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'thumbnail',
            [
                'label' => esc_html__('Thumbnail', 'corpix-core'),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
                'default' => [ 'url' => Utils::get_placeholder_image_src() ],
            ]
        );

        $this->add_control(
            'link',
            [
                'label' => __( 'Link', 'corpix-core' ),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'corpix-core' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                ],
            ]
        );


        $this->add_control(
            'title',
            [
                'label' => __( 'Title', 'corpix-core' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __( 'Multi website launch', 'corpix-core' ),
                'placeholder' => __( 'Type your Title here', 'corpix-core' ),
                
            ]
        );

        $this->add_control(
            'subtitle',
            [
                'label' => __( 'Subtitle', 'corpix-core' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __( 'Web Design', 'corpix-core' ),
                'placeholder' => __( 'Type your Subtitle here', 'corpix-core' ),
                
            ]
        );

        $this->end_controls_section();



        /*-----------------------------------------------------------------------------------*/
        /*  STYLES -> IMAGES
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_images',
            [
                'label' => esc_html__('Style', 'corpix-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );



        $this->add_responsive_control(
			'image_size',
			[
				'label' => esc_html__( 'Height', 'elementor' ),
				'type' => Controls_Manager::SLIDER,
				'default' => [
					'unit' => 'px',
				],
				'tablet_default' => [
					'unit' => 'px',
				],
				'mobile_default' => [
					'unit' => 'px',
				],
				'size_units' => [ 'px', 'vh' ],
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 1000,
					],
					'vh' => [
						'min' => 1,
						'max' => 100,
					],
				],
				'selectors' => [
					'{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-link img' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

        

       
        $this->end_controls_section();



        $this->start_controls_section(
            'project_content_position',
            [
                'label' => esc_html__('Content Position', 'corpix-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );


        $this->add_responsive_control(
            'content_bottom_space',
            [
                'label' => esc_html__( 'Position-Y', 'elementor' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-content' => 'bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_left_space',
            [
                'label' => esc_html__( 'Position-X', 'elementor' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-content' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

    // Project Title Style start

    $this->start_controls_section(
        'project_title',
        [
            'label'     => __( 'Title', 'corpix-core' ),
            'tab'       => Controls_Manager::TAB_STYLE,
        ]
    );

    $this->add_control(
        'project_title_color',
        [
            'label' => __( 'Color', 'corpix-core' ),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-content .title' => 'color: {{VALUE}};',
            ],
        ]
    );

    $this->add_control(
        'title_bg_color',
        [
            'label' => __( 'Title Background Color', 'corpix-core' ),
            'type' => Controls_Manager::COLOR,
            'default' => '',
            'selectors' => [
                '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-content .title' => 'background-color: {{VALUE}};',
            ],
        ]
    );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'project_title_typography',
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
                ],
                'selector' => '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-content .title',
            ]
        );

        $this->add_responsive_control(
            'title_bottom_space',
            [
                'label' => esc_html__( 'Spacing', 'elementor' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-content .title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );


    $this->end_controls_section(); // Project Title Style end

    // Project subtitle Style start
    $this->start_controls_section(
        'project_subtitle_style',
        [
            'label'     => __( 'Sub Title', 'corpix-core' ),
            'tab'       => Controls_Manager::TAB_STYLE,
        ]
    );
        
        $this->add_control(
            'project_subtitle_color',
            [
                'label' => __( 'Color', 'corpix-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-content .sub-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'subtitle_bg_color',
            [
                'label' => __( 'Subtitle Background Color', 'corpix-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-content .sub-title' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'project_subtitle_typography',
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_TEXT,
                ],
                'selector' => '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-content .sub-title', 
            ]
        );

        $this->add_responsive_control(
            'subtitle_bottom_space',
            [
                'label' => esc_html__( 'Spacing', 'elementor' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-content .sub-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );


    $this->end_controls_section(); // Project subtitle style end




    // Project Shape 1 Position Style start
    $this->start_controls_section(
        'project_shape1_style',
        [
            'label'     => __( 'Project Shape-1 Position', 'corpix-core' ),
            'tab'       => Controls_Manager::TAB_STYLE,
        ]
    );
      
    $this->add_control(
        'shape_1_position_y)',
        [
            'label' => esc_html__( 'Position-Y', 'corpix-core' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-link::before' => 'bottom: {{SIZE}}{{UNIT}};',
                ],
        ]
    );

    $this->add_control(
        'shape_1_position_x)',
        [
            'label' => esc_html__( 'Position-X', 'corpix-core' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-link::before' => 'right: {{SIZE}}{{UNIT}};',
                ],
        ]
    );
    

    $this->end_controls_section(); // Project Shape 1 Position style end


     // Project Shape 2 Position Style start
     $this->start_controls_section(
        'project_shape2_style',
        [
            'label'     => __( 'Project Shape-2 Position', 'corpix-core' ),
            'tab'       => Controls_Manager::TAB_STYLE,
        ]
    );
      
    $this->add_control(
        'shape_2_position_y)',
        [
            'label' => esc_html__( 'Position-Y', 'corpix-core' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-link::after' => 'bottom: {{SIZE}}{{UNIT}};',
                ],
        ]
    );

    $this->add_control(
        'shape_2_position_x)',
        [
            'label' => esc_html__( 'Position-X', 'corpix-core' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 500,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .tpc-work-item .tpc-work-wrapper .tpc-work-link::after' => 'right: {{SIZE}}{{UNIT}};',
                ],
        ]
    );
    

    $this->end_controls_section(); // Project Shape 2 Position style end
}


    protected function render($instance = []){ 
        $settings = $this->get_settings_for_display();


        //$hover_style = ($settings['add_hover_effect'] == 'yes' ) ? ('hover-'.$settings['hover_style']) : ('');
        $hover_enable = ($settings['add_hover_effect'] == 'yes' ) ? ('hover-enabled'.' '.'hover-'.$settings['hover_style']) : ('');

        ?>
            <div class="tpc-work-item <?php echo(esc_attr($hover_enable))?>">
                <div class="tpc-work-wrapper">
                <div class="shape-1"></div>
                    
                    <?php if($settings['link']['url']): // a tag start ?>
                        <a class="tpc-work-link"<?php if($settings['link']['nofollow'] == 'on'): echo 'rel ="nofollow"'; endif;?> <?php if($settings['link']['is_external'] == 'on'): echo 'target="_blank"'; endif; ?> href="<?php echo $settings['link']['url'] ?>">
                    <?php endif ?>

                            <img src="<?php echo esc_url($settings['thumbnail']['url'])?>" alt="">

                    <?php if($settings['link']['url']): ?>
                        </a>
                    <?php endif; // a tag end?>

                    <div class="tpc-work-content">
                        <div class="title-wrap">
                            <h3 class="title"><?php echo $settings['title']; ?></h3>
                        </div>
                        <div class="subtitle-warp">
                            <h4 class="sub-title"><?php echo $settings['subtitle']; ?></h4>
                        </div>
                    </div>
                </div>
            </div>

<?php
}


}
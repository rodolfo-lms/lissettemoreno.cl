<?php $settings = $this->get_settings_for_display();?>

<div class="corpix-hero-section-02" style="background-image: url(assets/images/hero-2.jpg);">
	<div class="shape-4">
		<svg xmlns="http://www.w3.org/2000/svg">
			<path d="M0.11,726.77 L1025.850,0.3 L1878.992,1205.912 L853.130,1931.993 L0.11,726.77 Z"></path>
		</svg>
	</div>
	<div class="shape-5">
		<svg xmlns="http://www.w3.org/2000/svg">
			<path d="M462.968,0.4 L617.4,237.659 L154.31,537.993 L0.4,300.337 L462.968,0.4 Z"></path>
		</svg>
	</div>
	<div class="corpix-container">
		<div class="row justify-content-center">
			<div class="col-lg-12">
				<!-- Hero Content Start -->
				<div class="hero-content text-center">
					<div class="shape-1">
						<svg xmlns="http://www.w3.org/2000/svg">
							<path d="M833.643,0.981 L1111.7,406.951 L277.355,919.989 L0.8,514.19 L833.643,0.981 Z"></path>
						</svg>
					</div>
					<div class="shape-2">
						<svg xmlns="http://www.w3.org/2000/svg">
							<path d="M304.900,0.328 L307.99,3.669 L3.99,203.670 L0.900,200.328 L304.900,0.328 Z"></path>
						</svg>
					</div>
					<div class="shape-3">
						<svg xmlns="http://www.w3.org/2000/svg">
							<path d="M242.926,0.311 L245.73,3.685 L3.73,157.686 L0.926,154.312 L242.926,0.311 Z"></path>
						</svg>
					</div>
					<?php if($settings['sub_title']) : ?>
                        <h3 class="sub-title" data-aos-delay="600" data-aos="fade-up">
                            <?php echo $settings['sub_title']; ?>
                        </h3>
                    <?php endif;?> 
					<?php if($settings['title']) : ?>
                        <h2 class="title" data-aos="fade-up" data-aos-delay="700">
                            <?php echo $settings['title']; ?>
                        </h2>
                    <?php endif;?> 

					<?php if($settings['show_btn']) : ?>
                        <div class="corpix-hero-btn" data-aos="fade-up" data-aos-delay="900">
                            <?php if($settings['btn_link']['url']):?>
                                <a class="corpix-btn" <?php if($settings['btn_link']['nofollow'] == 'on'): echo 'rel ="nofollow"'; endif;?> <?php if($settings['btn_link']['is_external'] == 'on'): echo 'target="_blank"'; endif; ?> href="<?php echo $settings['btn_link']['url'] ?>">
                            <?php endif ?>
                                <?php echo $settings['btn_text']; ?> 

                                    <span class="btn-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg"  height="24px" viewBox="0 0 32 24" width="24px">
                                            <path d="m18.7188 6.78125-1.4376 1.4375 6.7813 6.78125h-20.0625v2h20.0625l-6.7813 6.7812 1.4376 1.4376 8.5-8.5.6874-.7188-.6874-.7188z" />
                                        </svg>
                                    </span>

                            <?php if($settings['btn_link']['url']): ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>

				</div>
				<!-- Hero Content End -->
			</div>
		</div>
	</div>
</div>
# WGL Customized Redux Framework Changelog

## 4.4.5
* Change domain name to unicoach-core
* ./class.redux-plugin
* ./redux-core/inc/classes/class-redux-page-render
* ./redux-core/inc/classes/class-redux-output: Custom Typography
* ./redux-core/class-redux-core
* ./redux-core/inc/classes/class-redux-wordpress-data
* ./redux-core/inc/classes/class-redux-output.php
* Remove: Redux_Functions_Ex::generator();
* ./redux-core/inc/validation/no_html/class-redux-validation-no-html.php Fix Demo Import for PHP 8
* ./redux-core/inc/classes/class-redux-api.php
* ./redux-core/framework.php
* ./redux-core/inc/extensions/social_profiles/*. replace all files
* ./redux-core/assets/css/redux-fields.min.css

* ./redux-core/inc/fields/typography/redux-typography.js

* ./redux-core/inc/extensions/customizer/class-redux-extension-customizer.php

* Remove css string from all files: .wp-customizer .redux-section.open .redux-group-tab{display:block !important}
* ./redux-core/assets/css/redux-admin.min.css